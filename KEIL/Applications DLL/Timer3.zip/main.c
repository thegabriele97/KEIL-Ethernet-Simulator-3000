#include <reg52.h>

// Timer 3 is identical to a standard Timer 1 of a 8051 but has different SFR 
// addresses so that it does not conflict with Timer 1
// The original Timer 1 SFR addresses and pins are:
// sfr TCON  = 0x88;
// sfr TMOD  = 0x89;
// sfr TL1   = 0x8B;
// sfr TH1   = 0x8D;
// T1 pin    = P3.5  Timer 1 external counter input
// INT1 pin  = P3.3  Timer 1 gate control

// The Timer 3 SFR addresses and pins are:
sfr T3CON   = 0xD8;   // Timer 3 register definitions
sfr T3MOD   = 0xD9;
sfr TL3     = 0xDA;
sfr TH3     = 0xDB;
// T3 pin   = P1.2  Timer 3 external counter input
// INT3 pin = P1.3  Timer 3 gate control


unsigned long NoT3Interrupts = 0;   // number of executed Timer 3 interrupts

void Timer3Interrupt (void) interrupt 7  {

  NoT3Interrupts++;
  TL3 = 0x20;    // Reload timer register
  TH3 = 0xA0;
}


void main(void) {

  IE |= 0xC0;    // set global and T3 interrupt enable bit  
  T3MOD = 0x10;  // 16 bit timer mode
  T3CON = 0x40;  // start Timer 3
  while(1);
}

