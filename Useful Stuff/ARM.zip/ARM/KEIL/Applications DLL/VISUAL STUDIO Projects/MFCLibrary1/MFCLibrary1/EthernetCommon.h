#pragma once

typedef enum {
	NEWCLIENT,
	ACK_NEWCLIENT,
	NEWDATA,
	DELCLIENT
} ETHNOTIFY;