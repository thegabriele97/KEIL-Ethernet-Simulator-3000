//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SPeriDLL.rc
//
#define IDC_AD_ADCCON1                  1870
#define IDC_AD_CONVST                   1872
#define IDC_AD_T2C                      1873
#define IDC_AD_RATE                     1874
#define IDC_AD_EXC                      1875
#define IDC_AD_SCONV                    1876
#define IDC_AD_ADCCON2                  1877
#define IDC_AD_AIN0                     1878
#define IDC_AD_AIN2                     1879
#define IDC_AD_AIN4                     1880
#define IDC_AD_AIN6                     1881
#define IDC_AD_AIN1                     1882
#define IDC_AD_AIN3                     1883
#define IDC_AD_AIN5                     1884
#define IDC_AD_AIN7                     1885
#define IDC_AD_VREF                     1886
#define IDC_AD_TEMP                     1887
#define IDC_AD_ADCCON3                  1888
#define IDC_AD_MODE                     1889
#define IDC_AD_CCONV                    1890
#define IDC_AD_ADCI                     1891
#define IDC_AD_DMA                      1892
#define IDC_AD_ADCDATA                  1893
#define IDC_AD_DMAPHL                   1894
#define IDC_AD_BUSY                     1895
#define IDC_AD_ACQUISITION              1898
#define IDC_AD_CLOCK                    1900
#define IDD_ADCON                       3004
#define IDC_AD_CHANNEL                  5060

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2000
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2000
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
