var modules =
[
    [ "UVSC Client Interface (UVSC_C.h)", "group__usvc__interface.html", "group__usvc__interface" ],
    [ "UVSOCK Interface (UVSOCK.h)", "group__uvsock__interface.html", "group__uvsock__interface" ]
];