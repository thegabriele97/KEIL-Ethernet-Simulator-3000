var structBKCHG =
[
    [ "nRes", "structBKCHG.html#a50fcf3c96222421d7cce77f20bbfe245", null ],
    [ "nTickMark", "structBKCHG.html#a6ebedb7f74973e590adfcbb66923db7f", null ],
    [ "type", "structBKCHG.html#aa0a2b7b7013049eeeff83f3428336f3c", null ]
];