var structEXECCMD =
[
    [ "__pad0__", "structEXECCMD.html#a6c873de1e2581afcc546a5655c21f358", null ],
    [ "bEcho", "structEXECCMD.html#aa76b1f9c45dfbfad54280ab58a64c80d", null ],
    [ "nRes", "structEXECCMD.html#a11bfa50c05567f2b1eebd8ace7abf424", null ],
    [ "sCmd", "structEXECCMD.html#a06567ccaa30c8a90cbac88291aad8f91", null ]
];