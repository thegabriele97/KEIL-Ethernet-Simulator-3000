var group__uvsc__pwrscl__func =
[
    [ "UVSC_POWERSCALE_SHOWCODE", "group__uvsc__pwrscl__func.html#gafb1a8c142de7f0d7a1b0ce3f717e5e00", null ]
];