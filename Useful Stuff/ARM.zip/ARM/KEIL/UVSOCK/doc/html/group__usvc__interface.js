var group__usvc__interface =
[
    [ "Client Defines", "group__usvc__defs.html", "group__usvc__defs" ],
    [ "Client Enumerations", "group__usvc__enums.html", "group__usvc__enums" ],
    [ "Client Structs", "group__usvc__structs.html", "group__usvc__structs" ],
    [ "Client Callback Typedefs", "group__usvc__typedefs.html", "group__usvc__typedefs" ],
    [ "Client Functions", "group__uvsc__func.html", "group__uvsc__func" ]
];