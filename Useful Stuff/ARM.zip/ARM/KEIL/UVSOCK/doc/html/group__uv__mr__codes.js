var group__uv__mr__codes =
[
    [ "UV_MR", "group__uv__mr__codes.html#ga0505331036ebe2d026333a8692352bd5", [
      [ "UV_MR_NONE", "group__uv__mr__codes.html#gga0505331036ebe2d026333a8692352bd5a6ff199d8ffc53aa9fafcc7c496fdacc0", null ],
      [ "UV_MR_ROM", "group__uv__mr__codes.html#gga0505331036ebe2d026333a8692352bd5afbe0d6fce7c538735f5da7e01aa58ca0", null ],
      [ "UV_MR_RAM", "group__uv__mr__codes.html#gga0505331036ebe2d026333a8692352bd5a90e2b485dc4a10b44fed9ccd157080c6", null ],
      [ "UV_MR_END", "UVSOCK_8h.html#ga0505331036ebe2d026333a8692352bd5a76fc5036a300f82056e700a5327f144a", null ]
    ] ],
    [ "UV_MR_NONE", "group__uv__mr__codes.html#gga0505331036ebe2d026333a8692352bd5a6ff199d8ffc53aa9fafcc7c496fdacc0", null ],
    [ "UV_MR_RAM", "group__uv__mr__codes.html#gga0505331036ebe2d026333a8692352bd5a90e2b485dc4a10b44fed9ccd157080c6", null ],
    [ "UV_MR_ROM", "group__uv__mr__codes.html#gga0505331036ebe2d026333a8692352bd5afbe0d6fce7c538735f5da7e01aa58ca0", null ]
];