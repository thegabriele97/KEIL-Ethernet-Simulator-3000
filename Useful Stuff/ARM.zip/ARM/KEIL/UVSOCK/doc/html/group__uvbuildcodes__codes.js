var group__uvbuildcodes__codes =
[
    [ "UVBUILDCODES", "group__uvbuildcodes__codes.html#ga046e8733734c0b6716df3cdcd844eb3b", [
      [ "UVBUILD_OK", "group__uvbuildcodes__codes.html#gga046e8733734c0b6716df3cdcd844eb3bab89662423eb98b9ab97435ce1948f395", null ],
      [ "UVBUILD_OK_WARNINGS", "group__uvbuildcodes__codes.html#gga046e8733734c0b6716df3cdcd844eb3baf5098a0046883cf7957b8f33373907c7", null ],
      [ "UVBUILD_ERRORS", "group__uvbuildcodes__codes.html#gga046e8733734c0b6716df3cdcd844eb3ba1bb29ea88c5b1ffd2974390d9542c6a5", null ],
      [ "UVBUILD_CANCELLED", "group__uvbuildcodes__codes.html#gga046e8733734c0b6716df3cdcd844eb3ba22ed19d69e352ae83966f321e21c2a48", null ],
      [ "UVBUILD_CLEANED", "group__uvbuildcodes__codes.html#gga046e8733734c0b6716df3cdcd844eb3ba5c76637daef1d16511e87eb0b1a13e5e", null ],
      [ "UVBUILD_CODES_END", "UVSOCK_8h.html#ga046e8733734c0b6716df3cdcd844eb3ba05281834f28dabc480ee50cee40ae966", null ]
    ] ],
    [ "UVBUILD_CANCELLED", "group__uvbuildcodes__codes.html#gga046e8733734c0b6716df3cdcd844eb3ba22ed19d69e352ae83966f321e21c2a48", null ],
    [ "UVBUILD_CLEANED", "group__uvbuildcodes__codes.html#gga046e8733734c0b6716df3cdcd844eb3ba5c76637daef1d16511e87eb0b1a13e5e", null ],
    [ "UVBUILD_ERRORS", "group__uvbuildcodes__codes.html#gga046e8733734c0b6716df3cdcd844eb3ba1bb29ea88c5b1ffd2974390d9542c6a5", null ],
    [ "UVBUILD_OK", "group__uvbuildcodes__codes.html#gga046e8733734c0b6716df3cdcd844eb3bab89662423eb98b9ab97435ce1948f395", null ],
    [ "UVBUILD_OK_WARNINGS", "group__uvbuildcodes__codes.html#gga046e8733734c0b6716df3cdcd844eb3baf5098a0046883cf7957b8f33373907c7", null ]
];