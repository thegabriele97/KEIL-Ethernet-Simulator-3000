var structBPREASON =
[
    [ "eReason", "structBPREASON.html#a1e1ad00da9d074363b1bdbae1d1ac37e", null ],
    [ "nAdr", "structBPREASON.html#ac95edcf699aab264d3b799709013cc31", null ],
    [ "nBpNum", "structBPREASON.html#a873874746c9b7639997953fd8dbf91d0", null ],
    [ "nPC", "structBPREASON.html#afa668e9c3bd26a590f03327232d11853", null ],
    [ "nRes", "structBPREASON.html#a74fc2702d2c76346ec30b35895ff4717", null ],
    [ "nRes1", "structBPREASON.html#aa252d4a192d00e5672601659251d4591", null ],
    [ "nRes2", "structBPREASON.html#a1250b2f7dfcdff49af2817c711239b9f", null ],
    [ "nTickMark", "structBPREASON.html#adb07a6feb1a24a3fcccabf2fee463ca3", null ],
    [ "StrLen", "structBPREASON.html#a4c7bb81adc15c86044d44f6c3fec7397", null ]
];