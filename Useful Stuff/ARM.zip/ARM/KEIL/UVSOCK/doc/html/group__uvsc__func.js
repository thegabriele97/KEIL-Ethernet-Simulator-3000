var group__uvsc__func =
[
    [ "Connection Control Functions", "group__uvsc__ctrl__func.html", "group__uvsc__ctrl__func" ],
    [ "General Functions", "group__uvsc__gen__func.html", "group__uvsc__gen__func" ],
    [ "Project Functions", "group__uvsc__prj__func.html", "group__uvsc__prj__func" ],
    [ "Debug Functions", "group__uvsc__dbg__func.html", "group__uvsc__dbg__func" ],
    [ "Build Output Functions", "group__uvsc__bldo__func.html", "group__uvsc__bldo__func" ],
    [ "Command Output Functions", "group__uvsc__cmdo__func.html", "group__uvsc__cmdo__func" ],
    [ "Queue Functions", "group__uvsc__que__func.html", "group__uvsc__que__func" ],
    [ "Powerscale Functions", "group__uvsc__pwrscl__func.html", "group__uvsc__pwrscl__func" ],
    [ "Advanced Client Functions", "group__uvsc__adv__func.html", "group__uvsc__adv__func" ]
];