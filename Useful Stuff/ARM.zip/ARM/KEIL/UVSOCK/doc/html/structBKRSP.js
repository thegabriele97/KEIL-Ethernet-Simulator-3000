var structBKRSP =
[
    [ "count", "structBKRSP.html#ab551a4a231c65f6d5f3c174537ca9f09", null ],
    [ "enabled", "structBKRSP.html#a01406b0b968d1a74f7fa08742b03147a", null ],
    [ "nAddress", "structBKRSP.html#ab9b8e8696d75cfe535a61fef5abd0547", null ],
    [ "nExpLen", "structBKRSP.html#aede3dc0217aad9d80a955109708eafbe", null ],
    [ "nTickMark", "structBKRSP.html#ad0dc24865bd51b386c8ca0a3315514ae", null ],
    [ "szBuffer", "structBKRSP.html#a8fc6b27da992e362ad6ac7ead5ad5e14", null ],
    [ "type", "structBKRSP.html#ac2b51ded4ee635fda4830aaaa83c3420", null ]
];