var group__uv__target__codes =
[
    [ "UV_TARGET", "group__uv__target__codes.html#gaf0c260535dd19da69720be660f074e4a", [
      [ "UV_TARGET_HW", "group__uv__target__codes.html#ggaf0c260535dd19da69720be660f074e4aa19d913ea76d5352a94361d37c7036a3c", null ],
      [ "UV_TARGET_SIM", "group__uv__target__codes.html#ggaf0c260535dd19da69720be660f074e4aacd6c9c37acb4b0d0ebaded69ba78a2b0", null ],
      [ "UV_TARGET_END", "UVSOCK_8h.html#gaf0c260535dd19da69720be660f074e4aacf46c5ddd77345aa973752138e3aa5fd", null ]
    ] ],
    [ "UV_TARGET_HW", "group__uv__target__codes.html#ggaf0c260535dd19da69720be660f074e4aa19d913ea76d5352a94361d37c7036a3c", null ],
    [ "UV_TARGET_SIM", "group__uv__target__codes.html#ggaf0c260535dd19da69720be660f074e4aacd6c9c37acb4b0d0ebaded69ba78a2b0", null ]
];