var group__uvsock__interface =
[
    [ "Macros", "group__uvsock__macros.html", "group__uvsock__macros" ],
    [ "Typedefs", "group__uvsock__typedefs.html", "group__uvsock__typedefs" ],
    [ "Enumerations", "group__uvsock__enums.html", "group__uvsock__enums" ],
    [ "Structs", "group__uvsock__structs.html", "group__uvsock__structs" ]
];