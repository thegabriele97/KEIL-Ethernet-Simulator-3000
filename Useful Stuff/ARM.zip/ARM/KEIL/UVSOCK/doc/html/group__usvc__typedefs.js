var group__usvc__typedefs =
[
    [ "log_cb", "group__usvc__typedefs.html#gaf8d09a4de76a8b25ad9189805b527751", null ],
    [ "uvsc_cb", "group__usvc__typedefs.html#ga7df8d5de58c0a72d7ccc4de61ac46b8f", null ]
];