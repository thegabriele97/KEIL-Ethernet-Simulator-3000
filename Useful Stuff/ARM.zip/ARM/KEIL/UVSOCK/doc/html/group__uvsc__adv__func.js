var group__uvsc__adv__func =
[
    [ "UVSC_CreateMsg", "group__uvsc__adv__func.html#gaffa0bc9f6d1e0f15e97817605d075e38", null ],
    [ "UVSC_DBG_DSM_READ", "group__uvsc__adv__func.html#ga8fd71db6b618d0bcf2834810b4355a84", null ],
    [ "UVSC_DBG_ENUM_REGISTER_GROUPS", "group__uvsc__adv__func.html#ga9f9277bb0e256322ab74c472d4e9ff52", null ],
    [ "UVSC_DBG_ENUM_REGISTERS", "group__uvsc__adv__func.html#gafc8487c28431f901689cdc02a815fbe6", null ],
    [ "UVSC_DBG_EVAL_EXPRESSION_TO_STR", "group__uvsc__adv__func.html#ga55ad769f8e74475d45149cd3be3b450e", null ],
    [ "UVSC_DBG_FILELINE_TO_ADR", "group__uvsc__adv__func.html#ga9ec99be27534a12be8108ca28e89feed", null ],
    [ "UVSC_DBG_READ_REGISTERS", "group__uvsc__adv__func.html#ga102fe61bac75d555d4bc0e6c705d9dae", null ],
    [ "UVSC_DBG_REGISTER_SET", "group__uvsc__adv__func.html#ga18cf92e9c169514b130683b3a9281941", null ],
    [ "UVSC_TxRxRaw", "group__uvsc__adv__func.html#gac360de99eaf29dbcbf2585b67d8c0b75", null ]
];