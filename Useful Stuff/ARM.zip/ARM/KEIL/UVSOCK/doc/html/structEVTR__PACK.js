var structEVTR__PACK =
[
    [ "data", "structEVTR__PACK.html#a5132391cebbf8fc5333cd5c5216c4f0e", null ],
    [ "dec", "structEVTR__PACK.html#a2efd7bfd65e2b45fb2909a416b85e8c8", null ],
    [ "nMany", "structEVTR__PACK.html#aae5b22cdb39c23d7b28305c521106cfa", null ],
    [ "nType", "structEVTR__PACK.html#a8b49fe65fda9b168bf0d6f10edfb51b0", null ],
    [ "raw", "structEVTR__PACK.html#ab2dbcb9eb76e17ce72b87a75d54fb514", null ]
];