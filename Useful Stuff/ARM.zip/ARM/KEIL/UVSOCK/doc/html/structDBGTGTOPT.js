var structDBGTGTOPT =
[
    [ "__pad0__", "structDBGTGTOPT.html#a470ead8ca95f1c3754842c7d4080f755", null ],
    [ "nRes", "structDBGTGTOPT.html#a45a26bb826341abb2a2540d71919f0db", null ],
    [ "target", "structDBGTGTOPT.html#a434bfbc4edd18b15005bd432c9651670", null ]
];