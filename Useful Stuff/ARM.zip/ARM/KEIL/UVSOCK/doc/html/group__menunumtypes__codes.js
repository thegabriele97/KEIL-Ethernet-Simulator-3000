var group__menunumtypes__codes =
[
    [ "MENUENUMTYPES", "group__menunumtypes__codes.html#ga71163a0a8024512524bd81be42020979", [
      [ "MENU_INFO_ITEM", "group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979ac2f36a62081b7b6991afef5807673ef2", null ],
      [ "MENU_INFO_GROUP", "group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979ac3cc1893d854177a411ad3cbf05a6d54", null ],
      [ "MENU_INFO_GROUP_END", "group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979a0ecb8ffb403f55ff33789afb1d7d6757", null ],
      [ "MENU_INFO_LIST_END", "group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979a29b48d53b347d09d5df36ddd4c31798d", null ],
      [ "MENU_INFO_RESERVED", "group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979a6e26737acc1879b2f25bc9d3f1920d69", null ],
      [ "MENU_INFO_END", "UVSOCK_8h.html#ga71163a0a8024512524bd81be42020979a6d56152f278e6f987a1cd1ffe1f202bc", null ]
    ] ],
    [ "MENU_INFO_GROUP", "group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979ac3cc1893d854177a411ad3cbf05a6d54", null ],
    [ "MENU_INFO_GROUP_END", "group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979a0ecb8ffb403f55ff33789afb1d7d6757", null ],
    [ "MENU_INFO_ITEM", "group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979ac2f36a62081b7b6991afef5807673ef2", null ],
    [ "MENU_INFO_LIST_END", "group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979a29b48d53b347d09d5df36ddd4c31798d", null ],
    [ "MENU_INFO_RESERVED", "group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979a6e26737acc1879b2f25bc9d3f1920d69", null ]
];