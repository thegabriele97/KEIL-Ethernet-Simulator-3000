var structENUMTPM =
[
    [ "Job", "structENUMTPM.html#a694363b690b5f278a4c7ccdf9f628b18", null ],
    [ "nOffs", "structENUMTPM.html#abbb6b9c5441703e90ab37265c19000c2", null ],
    [ "nRes", "structENUMTPM.html#a5c36c9775d7348b9e8bc39c38e631fff", null ],
    [ "nSize", "structENUMTPM.html#a7e4b34ed02446a975d49d3a1c11e199e", null ],
    [ "szID", "structENUMTPM.html#ad06d26d22e09c75b75996602c6219c9b", null ]
];