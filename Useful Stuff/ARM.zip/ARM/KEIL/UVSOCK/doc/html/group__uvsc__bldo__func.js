var group__uvsc__bldo__func =
[
    [ "UVSC_GetBuildOutput", "group__uvsc__bldo__func.html#ga5640d0c240c01498878cdf69694f35e2", null ],
    [ "UVSC_GetBuildOutputSize", "group__uvsc__bldo__func.html#ga7f33e687582fcc94678760662dc0fd1d", null ]
];