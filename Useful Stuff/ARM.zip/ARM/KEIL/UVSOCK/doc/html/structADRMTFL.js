var structADRMTFL =
[
    [ "__pad0__", "structADRMTFL.html#aa52b2ea2b282a977dc67680f05e39cc3", null ],
    [ "bFull", "structADRMTFL.html#a960b9bda93d6cf3665682294385e8f1b", null ],
    [ "nAdr", "structADRMTFL.html#a8a055bed4976b946c2aa8682940493a8", null ],
    [ "nRes", "structADRMTFL.html#a23c8dfb13715386ba15c3662a29a0336", null ]
];