var structCYCTS =
[
    [ "cycles", "structCYCTS.html#ae32f3115d7074806de659d6ed1b3f90e", null ],
    [ "tStamp", "structCYCTS.html#a1947ac02d2a578fa7b588104bb21fa3f", null ]
];