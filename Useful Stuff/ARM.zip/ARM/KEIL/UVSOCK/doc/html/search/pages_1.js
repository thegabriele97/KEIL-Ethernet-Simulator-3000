var searchData=
[
  ['direct_20interface_20_28uvsock_29',['Direct Interface (UVSOCK)',['../direct_sec.html',1,'']]]
];
