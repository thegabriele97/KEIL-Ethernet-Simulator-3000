var searchData=
[
  ['menu_20enumeration_20codes',['Menu Enumeration Codes',['../group__menunumtypes__codes.html',1,'']]],
  ['memory_20type_20codes',['Memory Type Codes',['../group__uv__mr__codes.html',1,'']]],
  ['macros',['Macros',['../group__uvsock__macros.html',1,'']]]
];
