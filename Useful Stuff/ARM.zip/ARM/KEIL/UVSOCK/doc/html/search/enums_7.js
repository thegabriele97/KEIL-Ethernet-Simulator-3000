var searchData=
[
  ['uv_5fmr',['UV_MR',['../group__uv__mr__codes.html#ga0505331036ebe2d026333a8692352bd5',1,'UVSOCK.h']]],
  ['uv_5foperation',['UV_OPERATION',['../group__operation__codes.html#ga99cef9125743ebfba84222416cdeb368',1,'UVSOCK.h']]],
  ['uv_5fstatus',['UV_STATUS',['../group__status__codes.html#gafd133b241db7cac0f1baaac6c492c5ee',1,'UVSOCK.h']]],
  ['uv_5ftarget',['UV_TARGET',['../group__uv__target__codes.html#gaf0c260535dd19da69720be660f074e4a',1,'UVSOCK.h']]],
  ['uvbuildcodes',['UVBUILDCODES',['../group__uvbuildcodes__codes.html#ga046e8733734c0b6716df3cdcd844eb3b',1,'UVSOCK.h']]],
  ['uvmenutypes',['UVMENUTYPES',['../group__uvmenutypes__codes.html#gaafb4d2759011e938986deca18d44dac4',1,'UVSOCK.h']]],
  ['uvsc_5fcb_5ftype',['UVSC_CB_TYPE',['../group__usvc__enums.html#ga55bf361fd2f0a0509e069c1ce9a538dd',1,'UVSC_C.h']]],
  ['uvsc_5fpbar',['UVSC_PBAR',['../group__usvc__enums.html#gad8881221f99fce970116cd1790a35139',1,'UVSC_C.h']]],
  ['uvsc_5frunmode',['UVSC_RUNMODE',['../group__usvc__enums.html#ga49745755375db102e66a92d2284d1edc',1,'UVSC_C.h']]],
  ['uvsc_5fstatus',['UVSC_STATUS',['../group__usvc__enums.html#gadadac39a0d05bddb1eb1240c1eeb1ecc',1,'UVSC_C.h']]]
];
