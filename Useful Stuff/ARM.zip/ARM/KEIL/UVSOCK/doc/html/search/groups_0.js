var searchData=
[
  ['advanced_20client_20functions',['Advanced Client Functions',['../group__uvsc__adv__func.html',1,'']]]
];
