var searchData=
[
  ['m_5fecmd',['m_eCmd',['../structUVSOCK__CMD.html#a40ec01b3a35b30664017da0b0ffb30b3',1,'UVSOCK_CMD']]],
  ['m_5fid',['m_Id',['../structUVSOCK__CMD.html#a82640b92ddeff49182522a44917742cf',1,'UVSOCK_CMD']]],
  ['m_5fnbuflen',['m_nBufLen',['../structUVSOCK__CMD.html#af609de1fd41601d23ece1038fc34a7dc',1,'UVSOCK_CMD']]],
  ['m_5fntotallen',['m_nTotalLen',['../structUVSOCK__CMD.html#a3b1916ba4948d0cd345cce1923d88cd4',1,'UVSOCK_CMD']]],
  ['menu_5finfo_5fend',['MENU_INFO_END',['../UVSOCK_8h.html#ga71163a0a8024512524bd81be42020979a6d56152f278e6f987a1cd1ffe1f202bc',1,'UVSOCK.h']]],
  ['menu_5finfo_5fgroup',['MENU_INFO_GROUP',['../group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979ac3cc1893d854177a411ad3cbf05a6d54',1,'UVSOCK.h']]],
  ['menu_5finfo_5fgroup_5fend',['MENU_INFO_GROUP_END',['../group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979a0ecb8ffb403f55ff33789afb1d7d6757',1,'UVSOCK.h']]],
  ['menu_5finfo_5fitem',['MENU_INFO_ITEM',['../group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979ac2f36a62081b7b6991afef5807673ef2',1,'UVSOCK.h']]],
  ['menu_5finfo_5flist_5fend',['MENU_INFO_LIST_END',['../group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979a29b48d53b347d09d5df36ddd4c31798d',1,'UVSOCK.h']]],
  ['menu_5finfo_5freserved',['MENU_INFO_RESERVED',['../group__menunumtypes__codes.html#gga71163a0a8024512524bd81be42020979a6e26737acc1879b2f25bc9d3f1920d69',1,'UVSOCK.h']]],
  ['menuenum',['MENUENUM',['../structMENUENUM.html',1,'']]],
  ['menuenumtypes',['MENUENUMTYPES',['../group__menunumtypes__codes.html#ga71163a0a8024512524bd81be42020979',1,'UVSOCK.h']]],
  ['menuid',['MENUID',['../structMENUID.html',1,'']]],
  ['menulabel',['menuLabel',['../structMENUENUM.html#a161c9b04c218bfa8fe62cab5fa52fb44',1,'MENUENUM']]],
  ['menu_20enumeration_20codes',['Menu Enumeration Codes',['../group__menunumtypes__codes.html',1,'']]],
  ['menutype',['menuType',['../structMENUID.html#a8435160434bdea4815b278dc41763b80',1,'MENUID::menuType()'],['../structMENUENUM.html#a42a29858b8f9a1f92a9f0555581c2fdb',1,'MENUENUM::menuType()']]],
  ['mr',['mr',['../structUV__MEMINFO.html#a203b02ee783ee5aa292d4ac1d4e59d9a',1,'UV_MEMINFO']]],
  ['msg',['msg',['../unionUVSC__CB__DATA.html#ada61493e497ab17bbe7b752a3f35809f',1,'UVSC_CB_DATA']]],
  ['mtype',['mType',['../structUV__MRANGE.html#a1e395acc1e48e5ba9f1a90eeea9b7f9f',1,'UV_MRANGE']]],
  ['memory_20type_20codes',['Memory Type Codes',['../group__uv__mr__codes.html',1,'']]],
  ['macros',['Macros',['../group__uvsock__macros.html',1,'']]]
];
