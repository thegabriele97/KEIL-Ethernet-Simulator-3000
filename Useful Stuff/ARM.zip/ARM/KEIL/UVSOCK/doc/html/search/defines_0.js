var searchData=
[
  ['evfmt_5fdec',['EVFMT_DEC',['../UVSOCK_8h.html#aac74df4bbc524463e68e4ab48c48d5da',1,'UVSOCK.h']]],
  ['evfmt_5fraw',['EVFMT_RAW',['../UVSOCK_8h.html#ab614dd5896466a43ceaef30cf3d9f2fe',1,'UVSOCK.h']]]
];
