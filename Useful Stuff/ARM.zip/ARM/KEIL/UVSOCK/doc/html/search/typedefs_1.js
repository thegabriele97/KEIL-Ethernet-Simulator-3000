var searchData=
[
  ['uvsc_5fcb',['uvsc_cb',['../group__usvc__typedefs.html#ga7df8d5de58c0a72d7ccc4de61ac46b8f',1,'UVSC_C.h']]]
];
