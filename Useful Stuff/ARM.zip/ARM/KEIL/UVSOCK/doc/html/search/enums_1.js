var searchData=
[
  ['chg_5ftype',['CHG_TYPE',['../group__chg__type__codes.html#ga7befb3aeb32f989fc210c511bb619c4a',1,'UVSOCK.h']]]
];
