var searchData=
[
  ['qualifiedname',['qualifiedName',['../structVARINFO.html#a4c8ab66870622c03e5d03c04407309a5',1,'VARINFO']]],
  ['queue_20functions',['Queue Functions',['../group__uvsc__que__func.html',1,'']]]
];
