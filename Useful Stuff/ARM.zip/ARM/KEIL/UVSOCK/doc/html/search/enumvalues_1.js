var searchData=
[
  ['chg_5fdisablebp',['CHG_DISABLEBP',['../group__chg__type__codes.html#gga7befb3aeb32f989fc210c511bb619c4aac67537bcbd33d8f1e5b25c1ad23b9e3c',1,'UVSOCK.h']]],
  ['chg_5fenablebp',['CHG_ENABLEBP',['../group__chg__type__codes.html#gga7befb3aeb32f989fc210c511bb619c4aae83fa6e6ae8efbadad238c672d5f64c1',1,'UVSOCK.h']]],
  ['chg_5fend',['CHG_END',['../UVSOCK_8h.html#ga7befb3aeb32f989fc210c511bb619c4aa9ffb704a7e59661caaa5d7432654e586',1,'UVSOCK.h']]],
  ['chg_5fkillbp',['CHG_KILLBP',['../group__chg__type__codes.html#gga7befb3aeb32f989fc210c511bb619c4aa1cf0ba794bf1a2e801b73fdf721b77cf',1,'UVSOCK.h']]]
];
