var searchData=
[
  ['bktype',['BKTYPE',['../group__bktype__codes.html#ga8ef3c20bc19a2a5a759bfcda2b97f3ab',1,'UVSOCK.h']]]
];
