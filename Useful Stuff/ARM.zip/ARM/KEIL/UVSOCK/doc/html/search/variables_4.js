var searchData=
[
  ['d',['d',['../structTVAL.html#afafbbb99187694346fd5ac6276623782',1,'TVAL']]],
  ['data',['data',['../structEVTR__CMDSTAT.html#ae315fbebf3651926d2fd4277dc0c7677',1,'EVTR_CMDSTAT::data()'],['../structEVTR__PACK.html#a5132391cebbf8fc5333cd5c5216c4f0e',1,'EVTR_PACK::data()'],['../structEVTROUT.html#a4b2a2ba4f6d609ef4a0009d415c60e15',1,'EVTROUT::data()'],['../structUVSOCK__CMD.html#af0417c9e34620e1abc536b2f6d18a016',1,'UVSOCK_CMD::data()']]],
  ['dbgtgtopt',['dbgtgtopt',['../structUVSOCK__CMD__RESPONSE.html#a54d96d066abe5e915438f2885030e802',1,'UVSOCK_CMD_RESPONSE::dbgtgtopt()'],['../unionUVSOCK__CMD__DATA.html#aaf66a0772baf3211a19c6fb79b616724',1,'UVSOCK_CMD_DATA::dbgtgtopt()']]],
  ['dec',['dec',['../structEVTR__PACK.html#a2efd7bfd65e2b45fb2909a416b85e8c8',1,'EVTR_PACK']]],
  ['delta',['delta',['../structUVSC__PSTAMP.html#a39fd0ef0931bdca0df2c9693c6515042',1,'UVSC_PSTAMP']]],
  ['dfltram',['dfltRam',['../structUV__MRANGE.html#a4cfae63315ad10b5707f8d330c124fe6',1,'UV_MRANGE']]],
  ['dfltrom',['dfltRom',['../structUV__MRANGE.html#a9afaeb3b330e3384ea88b6247a02cf0c',1,'UV_MRANGE']]]
];
