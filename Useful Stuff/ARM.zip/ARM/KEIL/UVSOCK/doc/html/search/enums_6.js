var searchData=
[
  ['stopreason',['STOPREASON',['../group__stopreason__codes.html#gaa2157b5eceb8a741b333aae33f37616d',1,'UVSOCK.h']]]
];
