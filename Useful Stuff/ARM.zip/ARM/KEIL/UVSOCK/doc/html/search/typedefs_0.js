var searchData=
[
  ['log_5fcb',['log_cb',['../group__usvc__typedefs.html#gaf8d09a4de76a8b25ad9189805b527751',1,'UVSC_C.h']]]
];
