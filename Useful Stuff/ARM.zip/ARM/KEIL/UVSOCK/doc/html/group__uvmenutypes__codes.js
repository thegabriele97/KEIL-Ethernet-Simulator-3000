var group__uvmenutypes__codes =
[
    [ "UVMENUTYPES", "group__uvmenutypes__codes.html#gaafb4d2759011e938986deca18d44dac4", [
      [ "UVMENU_DEBUG", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4a6a277935262efc75528d9cfb35bed951", null ],
      [ "UVMENU_SYS_VIEW", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4a50f8fa2465e178a081be580eb2e9e246", null ],
      [ "UVMENU_PERI", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4ae355cc603ca564f443f1eb228196c6e2", null ],
      [ "UVMENU_RTX", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4a5264d3005f738b7647ebd7d71244e785", null ],
      [ "UVMENU_CAN", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4a4566554ca93bc7be492c1fc012ef4838", null ],
      [ "UVMENU_AGDI", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4ab522d5837532be9d444e69e10662d2dc", null ],
      [ "UVMENU_TOOLBOX", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4a863526482fa2e53835861d14acce769e", null ],
      [ "UVMENU_END", "UVSOCK_8h.html#gaafb4d2759011e938986deca18d44dac4a9b8a3b0b447d3fcda3c5402d00f3a884", null ]
    ] ],
    [ "UVMENU_AGDI", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4ab522d5837532be9d444e69e10662d2dc", null ],
    [ "UVMENU_CAN", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4a4566554ca93bc7be492c1fc012ef4838", null ],
    [ "UVMENU_DEBUG", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4a6a277935262efc75528d9cfb35bed951", null ],
    [ "UVMENU_PERI", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4ae355cc603ca564f443f1eb228196c6e2", null ],
    [ "UVMENU_RTX", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4a5264d3005f738b7647ebd7d71244e785", null ],
    [ "UVMENU_SYS_VIEW", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4a50f8fa2465e178a081be580eb2e9e246", null ],
    [ "UVMENU_TOOLBOX", "group__uvmenutypes__codes.html#ggaafb4d2759011e938986deca18d44dac4a863526482fa2e53835861d14acce769e", null ]
];