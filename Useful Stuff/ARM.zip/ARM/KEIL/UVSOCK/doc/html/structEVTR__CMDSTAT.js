var structEVTR__CMDSTAT =
[
    [ "cmdStat", "structEVTR__CMDSTAT.html#abbd59f070a592e7cb8ce4da82bbc4d32", null ],
    [ "data", "structEVTR__CMDSTAT.html#ae315fbebf3651926d2fd4277dc0c7677", null ],
    [ "nMany", "structEVTR__CMDSTAT.html#a94f8d8fe0ca3c5918b2cc1752c40f9b6", null ]
];