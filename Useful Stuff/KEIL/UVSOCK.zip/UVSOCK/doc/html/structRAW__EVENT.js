var structRAW__EVENT =
[
    [ "complete", "structRAW__EVENT.html#a7e9ddef3a9cec571e06cf915302674c3", null ],
    [ "ctx", "structRAW__EVENT.html#a86c80b567af12a49a9f333fbe8aaa9e0", null ],
    [ "EvNumber", "structRAW__EVENT.html#a7ea897f91d7a52ffa5594385883e1dc8", null ],
    [ "id", "structRAW__EVENT.html#a2fff57bb1918f023680b8767b14f21d1", null ],
    [ "idx", "structRAW__EVENT.html#a0c71d3fd448d83c22601022917bb201f", null ],
    [ "irq", "structRAW__EVENT.html#afdda8527e38d7efe3825b4631241b7e8", null ],
    [ "last", "structRAW__EVENT.html#afa04afc23d450a3c3a8f384e963240ee", null ],
    [ "nRes", "structRAW__EVENT.html#abdf965a00e89216f25f631f78478822c", null ],
    [ "nType", "structRAW__EVENT.html#aa2750e6e1adecb445b0d189da5e80e0a", null ],
    [ "nValues", "structRAW__EVENT.html#a82a9cb8db0759bbdc9888d5f214464b6", null ],
    [ "overflowH", "structRAW__EVENT.html#a03fa11e235a18d8ab8d2acf54117f479", null ],
    [ "overflowL", "structRAW__EVENT.html#a62aa41b751210e5aac88eff69ea8050b", null ],
    [ "payload", "structRAW__EVENT.html#a95dc4b57d6c015845b123c0f39f4584a", null ],
    [ "recorderID", "structRAW__EVENT.html#abd410a0c840410b860d72e68b5dd36d4", null ],
    [ "reset", "structRAW__EVENT.html#a970bd838241fe4c19d30b0041f18e427", null ],
    [ "restartID", "structRAW__EVENT.html#a629a3a2f59575adaaeaf5f824be889fb", null ],
    [ "resume", "structRAW__EVENT.html#a7f2a6a3c5ecd7a4a44e510b780be9b87", null ],
    [ "tStamp", "structRAW__EVENT.html#a430dbb9fc394aa4293f5c3c19bfacee7", null ],
    [ "validID", "structRAW__EVENT.html#a53dbc18f6dbe2bdbd79ed9d5f5949885", null ]
];