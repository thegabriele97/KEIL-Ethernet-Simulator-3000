var structBKPARM =
[
    [ "accSize", "structBKPARM.html#a8e9a1b0f206327f2bf6b3a2830c74bcd", null ],
    [ "count", "structBKPARM.html#a264a4bd7632ab2421a553cdb3da2e59d", null ],
    [ "nCmdLen", "structBKPARM.html#a7caa5671c8357a55ba8810cc50f71b04", null ],
    [ "nExpLen", "structBKPARM.html#adc188b64ba0940cb6b6d100e8a7e3faa", null ],
    [ "szBuffer", "structBKPARM.html#ad52fea06f95f962efbc9b11536b810cb", null ],
    [ "type", "structBKPARM.html#aac0e143094eb215fcdcfd3263b4ffa6f", null ]
];