var structAMEM =
[
    [ "aBytes", "structAMEM.html#ae55e20cbc37b6e7908f1a1adf926a20f", null ],
    [ "ErrAddr", "structAMEM.html#ab08a0c7be85ca82747c2a36616dae076", null ],
    [ "nAddr", "structAMEM.html#a031acb1c6d7848e94bac5099cd07d274", null ],
    [ "nBytes", "structAMEM.html#afa0e1929faaa2aae053d9df888b650cb", null ],
    [ "nErr", "structAMEM.html#a7636c190095329bc5baca1ddace0fd59", null ]
];