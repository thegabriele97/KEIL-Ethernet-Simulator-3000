var uvsock_messaging =
[
    [ "General Message Format", "uvsock_messaging.html#spec_General", null ],
    [ "Request/Response Message", "uvsock_messaging.html#spec_req_resp_msg", null ],
    [ "Asynchronous Message", "uvsock_messaging.html#spec_async_msgs", null ],
    [ "Status Codes", "uvsock_messaging.html#uvsc_status_codes", null ],
    [ "UVSOCK Data Types", "uvsock_data_types.html", null ]
];