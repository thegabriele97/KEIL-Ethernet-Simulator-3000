var structEXTVERS =
[
    [ "iV_Sock", "structEXTVERS.html#ad2a41c22e0a82efd72c472a8320b2178", null ],
    [ "iV_Uv3", "structEXTVERS.html#ade566cc4aca55debb4f9b519d5d27535", null ],
    [ "nRes", "structEXTVERS.html#a388267093af330d3af1dc4c9a0f0be97", null ],
    [ "szBuffer", "structEXTVERS.html#ad2dce543265a7a1da9960a2a0058834e", null ]
];