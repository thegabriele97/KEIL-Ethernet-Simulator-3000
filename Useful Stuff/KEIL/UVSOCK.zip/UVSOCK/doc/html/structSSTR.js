var structSSTR =
[
    [ "nLen", "structSSTR.html#a589575a563e4040bcd1487c9324c949d", null ],
    [ "szStr", "structSSTR.html#a31e7b9bf3fb4b189d3401e9b9f7edd65", null ]
];