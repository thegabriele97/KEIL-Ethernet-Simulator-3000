var structAVTR =
[
    [ "__pad0__", "structAVTR.html#a5b6ea307fdc81344a91d012388832181", null ],
    [ "bValue", "structAVTR.html#a8d249ce93ad2ef55e237e777c58832a3", null ],
    [ "nRes", "structAVTR.html#ac265800cf483b5af43058c54d3a6b27f", null ],
    [ "szName", "structAVTR.html#ac0ef3ba3f5d55c931ff3bd784bdc5d35", null ],
    [ "value", "structAVTR.html#a5c1a832f3efd34b80f6fc77bbe1da7f4", null ],
    [ "vtrClock", "structAVTR.html#a727f56a4f876f4085dfb538807599fff", null ],
    [ "vtrFrq", "structAVTR.html#a828235128412888338a3ef234cdc0110", null ],
    [ "vtrNo", "structAVTR.html#a77e11fb373e22f9294cc05bb063b0c64", null ],
    [ "vtrType", "structAVTR.html#a1dd5511e5821b399d873d13d799f6c62", null ]
];