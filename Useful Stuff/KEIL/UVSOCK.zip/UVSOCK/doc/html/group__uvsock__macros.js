var group__uvsock__macros =
[
    [ "SOCK_NDATA", "group__uvsock__macros.html#ga2cd359cdb1162c2663264dde90558584", null ],
    [ "UV3_SOCKIF_VERS", "group__uvsock__macros.html#ga6ff9643540cb31dfbc4b3a24932b45da", null ],
    [ "xFALSE", "group__uvsock__macros.html#ga1f025bf0c83abc9c4895e1bca5070ed5", null ],
    [ "xTRUE", "group__uvsock__macros.html#gaac263c0e4e9bfc6af5e3985045c6fbf3", null ]
];