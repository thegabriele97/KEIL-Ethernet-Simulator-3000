var structTASKENUM =
[
    [ "__pad0__", "structTASKENUM.html#a415dbd79ad93cbd43dfd96abf239a6ea", null ],
    [ "nAdr", "structTASKENUM.html#a52c049d0703e514125c2c4cbb5157814", null ],
    [ "name", "structTASKENUM.html#a90b118c8d9edc55fd12389289a53d8b3", null ],
    [ "nState", "structTASKENUM.html#a918fc3537db1bc924ca6f78c8d0eec3c", null ],
    [ "nTask", "structTASKENUM.html#a46de59e78f33fb6d86dc9cbe1c15923d", null ]
];