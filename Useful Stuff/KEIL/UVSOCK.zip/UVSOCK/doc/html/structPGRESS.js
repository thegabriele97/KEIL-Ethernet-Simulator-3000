var structPGRESS =
[
    [ "job", "structPGRESS.html#af350f30113edc7e59579d0c0d66f6eba", null ],
    [ "nRes", "structPGRESS.html#a38adc1f764c982678234ce4af41dd325", null ],
    [ "perc", "structPGRESS.html#ab26d4097c69cd5daed4df6304d0bf028", null ],
    [ "szLabel", "structPGRESS.html#a379655198cca0c7af6aadfde53b1e782", null ]
];