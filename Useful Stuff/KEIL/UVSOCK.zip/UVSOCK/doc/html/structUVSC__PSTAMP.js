var structUVSC__PSTAMP =
[
    [ "delta", "structUVSC__PSTAMP.html#a39fd0ef0931bdca0df2c9693c6515042", null ],
    [ "nAdr", "structUVSC__PSTAMP.html#a867e0890da69b340caa75003da643e9f", null ],
    [ "nRes", "structUVSC__PSTAMP.html#a358be7add8a0b9f4bda7d9510b83c737", null ],
    [ "nReservedBits", "structUVSC__PSTAMP.html#ae231029dc7dc6e85543f4705235e2d07", null ],
    [ "showSyncErr", "structUVSC__PSTAMP.html#a54e4d6ed2d6c1a903e92e6b2a878a8f5", null ],
    [ "ticks", "structUVSC__PSTAMP.html#ab9d2dfd7d1a5e91363e3d14e16ebb227", null ],
    [ "time", "structUVSC__PSTAMP.html#a5057c67309b12e071c9a7755eaa9ef75", null ]
];