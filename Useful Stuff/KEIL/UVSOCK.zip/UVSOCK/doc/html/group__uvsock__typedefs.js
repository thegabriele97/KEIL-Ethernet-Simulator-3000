var group__uvsock__typedefs =
[
    [ "xBOOL", "group__uvsock__typedefs.html#ga3e89f2d425245466b27ba3600b116a22", null ],
    [ "xI64", "group__uvsock__typedefs.html#ga64a726abbdde12e4f38175ee1cc8402f", null ],
    [ "xINT16", "group__uvsock__typedefs.html#ga087ef5e5dff89efd9f53210bc198860e", null ],
    [ "xU64", "group__uvsock__typedefs.html#gad43617c3693e772d6d8659876870a777", null ],
    [ "xUC8", "group__uvsock__typedefs.html#gad4d975240bd4ac455194fc555029c400", null ],
    [ "xWORD16", "group__uvsock__typedefs.html#ga89c1c11996cae8e1657362bf38696e60", null ]
];