var structDEC__EVENT =
[
    [ "EvNumber", "structDEC__EVENT.html#afd450b0f8a974e87d3dda725f87c0736", null ],
    [ "nRes", "structDEC__EVENT.html#aacf209d95e953b590291f22d84aba784", null ],
    [ "nType", "structDEC__EVENT.html#a6c2a2e55f2192a81662f222591c4d9b0", null ],
    [ "szText", "structDEC__EVENT.html#a97d11b0faf60e47d888bf146a12b8a12", null ],
    [ "tStamp", "structDEC__EVENT.html#a3234aa895640b22ddffa58566d529e45", null ]
];