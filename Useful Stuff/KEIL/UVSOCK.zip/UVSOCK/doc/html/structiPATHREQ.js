var structiPATHREQ =
[
    [ "__pad0__", "structiPATHREQ.html#aeba2838dbc293626f0cf6d938c03e88b", null ],
    [ "bFull", "structiPATHREQ.html#a53e9970d1765889a53733bc8ce31efcb", null ],
    [ "nRes", "structiPATHREQ.html#ab9ca333b0f3a281865d9f6035bf59998", null ]
];