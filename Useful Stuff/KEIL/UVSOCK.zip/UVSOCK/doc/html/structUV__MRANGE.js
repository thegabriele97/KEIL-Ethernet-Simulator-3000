var structUV__MRANGE =
[
    [ "__pad0__", "structUV__MRANGE.html#a882ce7e92e598859aaac27f80379b795", null ],
    [ "dfltRam", "structUV__MRANGE.html#a4cfae63315ad10b5707f8d330c124fe6", null ],
    [ "dfltRom", "structUV__MRANGE.html#a9afaeb3b330e3384ea88b6247a02cf0c", null ],
    [ "isZiRam", "structUV__MRANGE.html#a379fde09b153537070c073a8e2b7b971", null ],
    [ "mType", "structUV__MRANGE.html#a1e395acc1e48e5ba9f1a90eeea9b7f9f", null ],
    [ "nRes", "structUV__MRANGE.html#aacac0587d8707ae546f24306296fc7f4", null ],
    [ "nSize", "structUV__MRANGE.html#a33b322145d0ddf46d932026a75f0ff9c", null ],
    [ "nStart", "structUV__MRANGE.html#a38af8ad56e12333a132248af9bb2aa78", null ]
];