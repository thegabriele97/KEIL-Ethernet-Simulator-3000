var structTVAL =
[
    [ "d", "structTVAL.html#afafbbb99187694346fd5ac6276623782", null ],
    [ "f", "structTVAL.html#ac4cb37a77a379f17a4ad9fe666090a5b", null ],
    [ "i", "structTVAL.html#aa058a8b4175354927a2cba84a2c1b1b8", null ],
    [ "i16", "structTVAL.html#a49bf9412416a1446135f6e9f0cfc0149", null ],
    [ "i64", "structTVAL.html#acfb09f638731f5b07fd297d775b05a01", null ],
    [ "l", "structTVAL.html#ad10f6d57c62db4992478839ea06278b3", null ],
    [ "sc", "structTVAL.html#a2eb813157738093aab057135ab3b24f7", null ],
    [ "u16", "structTVAL.html#a5057b054da88cab767bf216a6f60b595", null ],
    [ "u64", "structTVAL.html#a0f5e0467087fcb3db34a953e344e378d", null ],
    [ "uc", "structTVAL.html#a7f2e0bf4d323ed4225f5f3eb81dcab6e", null ],
    [ "ul", "structTVAL.html#ab3bac017be4d9deb5ade82d5f02e6035", null ],
    [ "v", "structTVAL.html#a1b75334a0116c966450d4da92d27b6bb", null ],
    [ "vType", "structTVAL.html#a7f1a0ff47b948750f6931e1108acdc2e", null ]
];