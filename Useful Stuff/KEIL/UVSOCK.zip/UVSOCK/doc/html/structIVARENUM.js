var structIVARENUM =
[
    [ "__pad0__", "structIVARENUM.html#ac746c4f35759e2d32f85ba89628640b9", null ],
    [ "bChanged", "structIVARENUM.html#a9ff13f40cc6ffa19223b4f299f9851a5", null ],
    [ "count", "structIVARENUM.html#aad0133600001f2bee55b9362c121f25b", null ],
    [ "nFrame", "structIVARENUM.html#a407a76a05cc72556661583c61a6d5fc0", null ],
    [ "nID", "structIVARENUM.html#abe8177ec1efc370c321765ac412b92eb", null ],
    [ "nTask", "structIVARENUM.html#aec3599e9b7369eee4c08ddd1f277383d", null ]
];