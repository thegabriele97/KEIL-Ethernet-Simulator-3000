var structUVSOCK__ERROR__RESPONSE =
[
    [ "nRes1", "structUVSOCK__ERROR__RESPONSE.html#aa3e3b07c7b12be2e097dd3e18eb79abb", null ],
    [ "nRes2", "structUVSOCK__ERROR__RESPONSE.html#a0479bcf5f1bb3abe649e804f5493d587", null ],
    [ "str", "structUVSOCK__ERROR__RESPONSE.html#ab0cd2684475fc04ae3344978b02abe5d", null ],
    [ "StrLen", "structUVSOCK__ERROR__RESPONSE.html#ab70fbac0261c53ad5e73dbc7e842e98c", null ]
];