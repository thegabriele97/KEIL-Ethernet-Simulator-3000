var structSTACKENUM =
[
    [ "nAdr", "structSTACKENUM.html#af7bd7278ac060913d2634135bbb91219", null ],
    [ "nEqual", "structSTACKENUM.html#ad017aeddef35aec2ffb734a6f6fc6aaf", null ],
    [ "nItem", "structSTACKENUM.html#a8074393340dca4b2dcc52e54e530ea7b", null ],
    [ "nRes", "structSTACKENUM.html#a3d9cd531d3a8605322797c74ecdd6655", null ],
    [ "nRetAdr", "structSTACKENUM.html#a0a3edb2abdaed91d6faab4238f0f58df", null ],
    [ "nTask", "structSTACKENUM.html#a958f80987114b6c7c69673da24c6ffb2", null ],
    [ "nTotal", "structSTACKENUM.html#af3ba67c1bc1570edac80c1948659659d", null ],
    [ "nVars", "structSTACKENUM.html#aeef850af8d50620a90b91b96c510c917", null ]
];