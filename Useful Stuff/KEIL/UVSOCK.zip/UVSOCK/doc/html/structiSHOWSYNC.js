var structiSHOWSYNC =
[
    [ "__pad0__", "structiSHOWSYNC.html#af7f50ee85c7a9fc4a88ab9f8c614424c", null ],
    [ "bAsm", "structiSHOWSYNC.html#a5166ec2468fde35fd05903ef650f8bb8", null ],
    [ "bAsmRes", "structiSHOWSYNC.html#a57eca628433777fe5f67a4274ea1b918", null ],
    [ "bHll", "structiSHOWSYNC.html#af3c1a17937fef467f2625d4a9e1ed9fd", null ],
    [ "bHllRes", "structiSHOWSYNC.html#aa29921fc21f3647cb87dc781859fcccf", null ],
    [ "nAdr", "structiSHOWSYNC.html#ab033a97f69c19c1e7abe27cd562f5261", null ],
    [ "nRes", "structiSHOWSYNC.html#a46d75e7d835f0a1c3817d1875cf2691b", null ]
];