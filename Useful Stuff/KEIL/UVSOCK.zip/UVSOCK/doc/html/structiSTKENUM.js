var structiSTKENUM =
[
    [ "__pad0__", "structiSTKENUM.html#acb92c720ccb647f1999d30c0f58979c9", null ],
    [ "bExtended", "structiSTKENUM.html#a454b102145bbd2198358b355156531c9", null ],
    [ "bFull", "structiSTKENUM.html#a55d6f6fa33d1a34e81b0fa664f39fc9f", null ],
    [ "bModified", "structiSTKENUM.html#a95dc24a87460f85b7497df955fbb7357", null ],
    [ "nRes", "structiSTKENUM.html#acdaac6d51a527908f37862bcc13054cd", null ],
    [ "nTask", "structiSTKENUM.html#a469ba22b7341241305d83e9a04b07a3b", null ]
];