var structVSET =
[
    [ "str", "structVSET.html#a92cca25e04a3ed45d5e036126afe3e3c", null ],
    [ "val", "structVSET.html#a7e9a41c79c5f33de6fb39af61e26d2b9", null ]
];