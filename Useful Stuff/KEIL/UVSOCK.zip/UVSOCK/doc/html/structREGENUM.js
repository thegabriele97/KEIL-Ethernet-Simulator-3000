var structREGENUM =
[
    [ "__pad0__", "structREGENUM.html#a49f0c28681ed2f2a048910e22b54c1cb", null ],
    [ "canChg", "structREGENUM.html#a69152c7ab7645803dc8ee6e845ea97f3", null ],
    [ "isPC", "structREGENUM.html#a8defbe3c6932ac7e6fc9e2b0f2c1244a", null ],
    [ "nGi", "structREGENUM.html#aeeb27e2621e6b6b756bf8edc3918e5ff", null ],
    [ "nItem", "structREGENUM.html#a6f69f895a671ca353b5ca9939cdd5615", null ],
    [ "szReg", "structREGENUM.html#ae3d01691618ff731b4f24f80d975b27b", null ],
    [ "szVal", "structREGENUM.html#ad63d30b288691899f2694bc594f9a52b", null ]
];