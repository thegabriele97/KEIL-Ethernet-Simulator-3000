var structITMOUT =
[
    [ "aBytes", "structITMOUT.html#a4b967f8e45e4649566df0223110991b8", null ],
    [ "aWords", "structITMOUT.html#ad2b81ed58f3a49de9ee75ba0af7aee90", null ],
    [ "itemMode", "structITMOUT.html#a5ca4997b1e38147ef05764d89b4ce5ab", null ],
    [ "nChannel", "structITMOUT.html#ab344fdc437f83889b18dfb701e32b549", null ],
    [ "nMany", "structITMOUT.html#af439f16b9ec10c6143ebd07c6bb1d177", null ],
    [ "s", "structITMOUT.html#ad8e6ad4dda97b46b9232077883c086da", null ]
];