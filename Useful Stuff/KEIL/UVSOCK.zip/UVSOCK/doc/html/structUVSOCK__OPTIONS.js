var structUVSOCK__OPTIONS =
[
    [ "__pad0__", "structUVSOCK__OPTIONS.html#a56207a785edbf3d87523f32fdb8a2268", null ],
    [ "bExtendedStack", "structUVSOCK__OPTIONS.html#a81137e11ac61a815a88b911b7de80358", null ]
];