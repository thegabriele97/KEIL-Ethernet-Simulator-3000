var group__uvsc__gen__func =
[
    [ "UVSC_GEN_CHECK_LICENSE", "group__uvsc__gen__func.html#ga728b3290432bb032d9ea9d0265d5e4bb", null ],
    [ "UVSC_GEN_EXT_VERSION", "group__uvsc__gen__func.html#ga20eef2a94137efc41873b9f5905bf074", null ],
    [ "UVSC_GEN_HIDE", "group__uvsc__gen__func.html#ga1c571015bd4cf898587bb0b95f2e4a7c", null ],
    [ "UVSC_GEN_MAXIMIZE", "group__uvsc__gen__func.html#ga19d4d7c49429d5b89a6cf1ccb19b0a64", null ],
    [ "UVSC_GEN_MINIMIZE", "group__uvsc__gen__func.html#gae268491163a4566d1e18f597c8b8ac21", null ],
    [ "UVSC_GEN_RESTORE", "group__uvsc__gen__func.html#gaa0aa81be0768c093195a15aa18d7f143", null ],
    [ "UVSC_GEN_SET_OPTIONS", "group__uvsc__gen__func.html#gac011ca3556185f14b126b90829bd447d", null ],
    [ "UVSC_GEN_SHOW", "group__uvsc__gen__func.html#ga78bdb4640af8a914f0b90ff33809122d", null ],
    [ "UVSC_GEN_UI_LOCK", "group__uvsc__gen__func.html#ga4b9f4c346926a1bfad1c5a6341a195c3", null ],
    [ "UVSC_GEN_UI_UNLOCK", "group__uvsc__gen__func.html#gac8d881b679bb1f81843e6a3b6f471dba", null ],
    [ "UVSC_GEN_UVSOCK_VERSION", "group__uvsc__gen__func.html#gae841b255b833933d810b6544a113158f", null ]
];