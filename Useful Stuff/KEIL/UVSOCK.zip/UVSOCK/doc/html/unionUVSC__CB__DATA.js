var unionUVSC__CB__DATA =
[
    [ "err", "unionUVSC__CB__DATA.html#a76cab5543669fb5b21dc493419f06929", null ],
    [ "iConnHandle", "unionUVSC__CB__DATA.html#a8283ac0d07dad9b3f65d6885708271ca", null ],
    [ "msg", "unionUVSC__CB__DATA.html#ada61493e497ab17bbe7b752a3f35809f", null ]
];