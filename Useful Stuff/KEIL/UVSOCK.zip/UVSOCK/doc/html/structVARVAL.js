var structVARVAL =
[
    [ "value", "structVARVAL.html#aa55462197a3dbd9f6347d5873e371c84", null ],
    [ "variable", "structVARVAL.html#a09ec33de6183ced52761618c00a8babb", null ]
];