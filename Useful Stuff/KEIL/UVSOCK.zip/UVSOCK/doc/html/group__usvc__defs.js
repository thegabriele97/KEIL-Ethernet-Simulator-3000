var group__usvc__defs =
[
    [ "_UVSC_FUNC_", "group__usvc__defs.html#gaa98bd3356e69afadc44d005d3c7bbbf3", null ],
    [ "UVSC_MAX_API_STR_SIZE", "group__usvc__defs.html#ga9d63e6de1db6ccacc329b4293d802983", null ],
    [ "UVSC_MAX_AUTO_PORT", "group__usvc__defs.html#ga54e54a65c3bd512555f7467d1178e585", null ],
    [ "UVSC_MAX_CLIENTS", "group__usvc__defs.html#ga35297034e80e69c6cbd24351e30f1008", null ],
    [ "UVSC_MIN_AUTO_PORT", "group__usvc__defs.html#ga17caa190343ed24573c5bafc034c54d5", null ],
    [ "UVSC_PORT_AUTO", "group__usvc__defs.html#ga58554e35b437d804e0f5182c661584e7", null ]
];