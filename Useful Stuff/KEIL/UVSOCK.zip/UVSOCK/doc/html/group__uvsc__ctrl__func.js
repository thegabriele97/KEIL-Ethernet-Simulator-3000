var group__uvsc__ctrl__func =
[
    [ "UVSC_CloseConnection", "group__uvsc__ctrl__func.html#ga04490f7bc377dca9f36fa19cf65f8532", null ],
    [ "UVSC_ConnHandleFromConnName", "group__uvsc__ctrl__func.html#ga5971c6014321a7250fbbfc4434aafa4c", null ],
    [ "UVSC_GetLastError", "group__uvsc__ctrl__func.html#ga2de6d2554403594841261d5dad14893e", null ],
    [ "UVSC_Init", "group__uvsc__ctrl__func.html#ga1810ba2b32a5e91e3f53bd23bc75c2d5", null ],
    [ "UVSC_LogControl", "group__uvsc__ctrl__func.html#ga083a4b4ab04135be42147fa7451b13c4", null ],
    [ "UVSC_OpenConnection", "group__uvsc__ctrl__func.html#ga4d5d8f897604d8b3e8b6ec03150b92db", null ],
    [ "UVSC_UnInit", "group__uvsc__ctrl__func.html#ga8f518330fe4842e2a29492cf20f49575", null ],
    [ "UVSC_Version", "group__uvsc__ctrl__func.html#gac3372cf6ae5b1f3bed207527f8b28720", null ]
];