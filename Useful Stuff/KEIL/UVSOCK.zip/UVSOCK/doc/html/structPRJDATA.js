var structPRJDATA =
[
    [ "nCode", "structPRJDATA.html#a8041ea14f0ab64b75d1b941bacc45b4c", null ],
    [ "nLen", "structPRJDATA.html#ab3fee924d7dd9b6ddc89ef62c4360c90", null ],
    [ "szNames", "structPRJDATA.html#aee09a4081b34cae3c373fee4ca4f43b8", null ]
];