var structEVTROUT =
[
    [ "data", "structEVTROUT.html#a4b2a2ba4f6d609ef4a0009d415c60e15", null ],
    [ "nMany", "structEVTROUT.html#af0fc4b87db7ca68cc527301ed108e653", null ],
    [ "nRes", "structEVTROUT.html#adce7aa4779f238cec109d6520d7583ba", null ],
    [ "pack", "structEVTROUT.html#ac8cc3db15304bf0967edbca23ad60fd8", null ]
];