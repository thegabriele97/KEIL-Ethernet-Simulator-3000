var group__entpjob__codes =
[
    [ "ENTPJOB", "group__entpjob__codes.html#ga45124c56adf7be43b9b4f4948bc81310", [
      [ "UV_TPENUM_MEMBERS", "group__entpjob__codes.html#gga45124c56adf7be43b9b4f4948bc81310a3a463c5c62ac90fb8c22b291fb23607b", null ],
      [ "UV_TPENUM_END", "UVSOCK_8h.html#ga45124c56adf7be43b9b4f4948bc81310a9146aea4f14822a7b54409129db06811", null ]
    ] ],
    [ "UV_TPENUM_MEMBERS", "group__entpjob__codes.html#gga45124c56adf7be43b9b4f4948bc81310a3a463c5c62ac90fb8c22b291fb23607b", null ]
];