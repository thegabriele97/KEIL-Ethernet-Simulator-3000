var structiINTERVAL =
[
    [ "__pad0__", "structiINTERVAL.html#a31e1c7ccfcb39f11127bc915f08fe4aa", null ],
    [ "bAutoStart", "structiINTERVAL.html#a54ca8b22306a116723d8815cf0c44c85", null ],
    [ "bCycles", "structiINTERVAL.html#afaa495bcc5d9cfcd7250789ac2f4eef3", null ],
    [ "bSetInterval", "structiINTERVAL.html#a7afa402457b24355ea1514656caf2b4f", null ],
    [ "fSeconds", "structiINTERVAL.html#a514bb6aa2f8fac01f9fa558605996d13", null ],
    [ "iCycles", "structiINTERVAL.html#a69efb807386fc51b3bc01a00010a4cbe", null ],
    [ "nRes", "structiINTERVAL.html#a2c1edde68b148339b16821d3ec5c88b7", null ]
];