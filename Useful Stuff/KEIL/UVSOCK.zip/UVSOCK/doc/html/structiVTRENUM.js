var structiVTRENUM =
[
    [ "__pad0__", "structiVTRENUM.html#ac48f92bc17ca30683f44cfb95a4632a9", null ],
    [ "bValue", "structiVTRENUM.html#a7fc905393dbdff820c2c6003ca968534", null ],
    [ "nRes", "structiVTRENUM.html#afbbc0ff1903c05b6fbb9bc4acddac20a", null ]
];