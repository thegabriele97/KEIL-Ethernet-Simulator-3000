var structUVSOCK__CMD =
[
    [ "cycles", "structUVSOCK__CMD.html#aa1a8acd8afc1cf7d93927dda6be20288", null ],
    [ "data", "structUVSOCK__CMD.html#af0417c9e34620e1abc536b2f6d18a016", null ],
    [ "m_eCmd", "structUVSOCK__CMD.html#a40ec01b3a35b30664017da0b0ffb30b3", null ],
    [ "m_Id", "structUVSOCK__CMD.html#a82640b92ddeff49182522a44917742cf", null ],
    [ "m_nBufLen", "structUVSOCK__CMD.html#af609de1fd41601d23ece1038fc34a7dc", null ],
    [ "m_nTotalLen", "structUVSOCK__CMD.html#a3b1916ba4948d0cd345cce1923d88cd4", null ],
    [ "tStamp", "structUVSOCK__CMD.html#ae8914fb33564e45b39bae0ac8d2f76f3", null ]
];