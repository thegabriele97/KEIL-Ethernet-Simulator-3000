var structUV__MEMINFO =
[
    [ "mr", "structUV__MEMINFO.html#a203b02ee783ee5aa292d4ac1d4e59d9a", null ],
    [ "nRanges", "structUV__MEMINFO.html#ab1d414ab0a7701116e9d84ab39bcfb62", null ],
    [ "nRes", "structUV__MEMINFO.html#a77656ef771334bf10af669e99de6ddfc", null ]
];