var structTRNOPT =
[
    [ "iFile", "structTRNOPT.html#a41434140bbb77077a2b54a981828971d", null ],
    [ "iGroup", "structTRNOPT.html#a8b00d009eefe4078478149acec81b60e", null ],
    [ "iItem", "structTRNOPT.html#afea982ca7011bbd89a0c81e4321a61c4", null ],
    [ "iTarg", "structTRNOPT.html#ad1019d8208d5c3666843e31dafa183c6", null ],
    [ "job", "structTRNOPT.html#aff6ac0aa9e0569c084197030a23c51ca", null ],
    [ "szBuffer", "structTRNOPT.html#af2c0bb1561306cb2b416009e9097e229", null ]
];