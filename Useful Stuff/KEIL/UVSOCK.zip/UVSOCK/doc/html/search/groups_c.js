var searchData=
[
  ['uvsc_20client_20interface_20_28uvsc_5fc_2eh_29',['UVSC Client Interface (UVSC_C.h)',['../group__usvc__interface.html',1,'']]],
  ['uvsock_20interface_20_28uvsock_2eh_29',['UVSOCK Interface (UVSOCK.h)',['../group__uvsock__interface.html',1,'']]]
];
