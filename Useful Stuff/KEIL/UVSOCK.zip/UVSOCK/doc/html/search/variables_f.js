var searchData=
[
  ['raw',['raw',['../structEVTR__PACK.html#ab2dbcb9eb76e17ce72b87a75d54fb514',1,'EVTR_PACK::raw()'],['../unionUVSOCK__CMD__DATA.html#aac1bca61b88b4501c2be8626d298aae5',1,'UVSOCK_CMD_DATA::raw()']]],
  ['recorderid',['recorderID',['../structRAW__EVENT.html#abd410a0c840410b860d72e68b5dd36d4',1,'RAW_EVENT']]],
  ['regenum',['regEnum',['../structUVSOCK__CMD__RESPONSE.html#abea66db730c971e00cc6da399e2f29e1',1,'UVSOCK_CMD_RESPONSE']]],
  ['reset',['reset',['../structRAW__EVENT.html#a970bd838241fe4c19d30b0041f18e427',1,'RAW_EVENT']]],
  ['restartid',['restartID',['../structRAW__EVENT.html#a629a3a2f59575adaaeaf5f824be889fb',1,'RAW_EVENT']]],
  ['resume',['resume',['../structRAW__EVENT.html#a7f2a6a3c5ecd7a4a44e510b780be9b87',1,'RAW_EVENT']]],
  ['rvmdk',['rvmdk',['../structUVLICINFO.html#ad88898b47d65e7ec7314436716adb2cb',1,'UVLICINFO']]]
];
