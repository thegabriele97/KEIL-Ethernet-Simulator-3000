var searchData=
[
  ['l',['l',['../structTVAL.html#ad10f6d57c62db4992478839ea06278b3',1,'TVAL']]],
  ['last',['last',['../structRAW__EVENT.html#afa04afc23d450a3c3a8f384e963240ee',1,'RAW_EVENT']]],
  ['licinfo',['licinfo',['../structUVSOCK__CMD__RESPONSE.html#a4b9151707c29b91f992287cfc652ed4c',1,'UVSOCK_CMD_RESPONSE']]],
  ['log_5fcb',['log_cb',['../group__usvc__typedefs.html#gaf8d09a4de76a8b25ad9189805b527751',1,'UVSC_C.h']]]
];
