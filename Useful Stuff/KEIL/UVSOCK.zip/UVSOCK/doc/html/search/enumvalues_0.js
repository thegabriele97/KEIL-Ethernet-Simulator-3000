var searchData=
[
  ['brktype_5fcomplex',['BRKTYPE_COMPLEX',['../group__bktype__codes.html#gga8ef3c20bc19a2a5a759bfcda2b97f3aba048909679a951fb1d5d96387571ff25b',1,'UVSOCK.h']]],
  ['brktype_5fend',['BRKTYPE_END',['../UVSOCK_8h.html#ga8ef3c20bc19a2a5a759bfcda2b97f3aba9021b07f386387bff769978b23a3dfd6',1,'UVSOCK.h']]],
  ['brktype_5fexec',['BRKTYPE_EXEC',['../group__bktype__codes.html#gga8ef3c20bc19a2a5a759bfcda2b97f3aba1e35fc5fee83ad4c8a3423bb430a37f6',1,'UVSOCK.h']]],
  ['brktype_5fread',['BRKTYPE_READ',['../group__bktype__codes.html#gga8ef3c20bc19a2a5a759bfcda2b97f3aba2d8c3096d5f4b52609c9f08182e94fe0',1,'UVSOCK.h']]],
  ['brktype_5freadwrite',['BRKTYPE_READWRITE',['../group__bktype__codes.html#gga8ef3c20bc19a2a5a759bfcda2b97f3aba44bd4905afc9db7a63992ab372e2b88c',1,'UVSOCK.h']]],
  ['brktype_5fwrite',['BRKTYPE_WRITE',['../group__bktype__codes.html#gga8ef3c20bc19a2a5a759bfcda2b97f3aba0a5368b2e7730eb81d43b76a304f0867',1,'UVSOCK.h']]]
];
