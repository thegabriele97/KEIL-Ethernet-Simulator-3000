var searchData=
[
  ['powerscale_5fopen',['POWERSCALE_OPEN',['../group__operation__codes.html#gga99cef9125743ebfba84222416cdeb368ae875dadcbc1d0a72814e2a5dabb1b247',1,'UVSOCK.h']]]
];
