var searchData=
[
  ['m_5fecmd',['m_eCmd',['../structUVSOCK__CMD.html#a40ec01b3a35b30664017da0b0ffb30b3',1,'UVSOCK_CMD']]],
  ['m_5fid',['m_Id',['../structUVSOCK__CMD.html#a82640b92ddeff49182522a44917742cf',1,'UVSOCK_CMD']]],
  ['m_5fnbuflen',['m_nBufLen',['../structUVSOCK__CMD.html#af609de1fd41601d23ece1038fc34a7dc',1,'UVSOCK_CMD']]],
  ['m_5fntotallen',['m_nTotalLen',['../structUVSOCK__CMD.html#a3b1916ba4948d0cd345cce1923d88cd4',1,'UVSOCK_CMD']]],
  ['menulabel',['menuLabel',['../structMENUENUM.html#a161c9b04c218bfa8fe62cab5fa52fb44',1,'MENUENUM']]],
  ['menutype',['menuType',['../structMENUID.html#a8435160434bdea4815b278dc41763b80',1,'MENUID::menuType()'],['../structMENUENUM.html#a42a29858b8f9a1f92a9f0555581c2fdb',1,'MENUENUM::menuType()']]],
  ['mr',['mr',['../structUV__MEMINFO.html#a203b02ee783ee5aa292d4ac1d4e59d9a',1,'UV_MEMINFO']]],
  ['msg',['msg',['../unionUVSC__CB__DATA.html#ada61493e497ab17bbe7b752a3f35809f',1,'UVSC_CB_DATA']]],
  ['mtype',['mType',['../structUV__MRANGE.html#a1e395acc1e48e5ba9f1a90eeea9b7f9f',1,'UV_MRANGE']]]
];
