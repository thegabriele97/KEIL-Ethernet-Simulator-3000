var searchData=
[
  ['client_20interface_20_28uvsc_29',['Client Interface (UVSC)',['../uvsc_sec.html',1,'']]]
];
