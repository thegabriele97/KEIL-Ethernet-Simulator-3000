var searchData=
[
  ['xbool',['xBOOL',['../group__uvsock__typedefs.html#ga3e89f2d425245466b27ba3600b116a22',1,'UVSOCK.h']]],
  ['xfalse',['xFALSE',['../group__uvsock__macros.html#ga1f025bf0c83abc9c4895e1bca5070ed5',1,'UVSOCK_H.txt']]],
  ['xi64',['xI64',['../group__uvsock__typedefs.html#ga64a726abbdde12e4f38175ee1cc8402f',1,'UVSOCK.h']]],
  ['xint16',['xINT16',['../group__uvsock__typedefs.html#ga087ef5e5dff89efd9f53210bc198860e',1,'UVSOCK.h']]],
  ['xtrue',['xTRUE',['../group__uvsock__macros.html#gaac263c0e4e9bfc6af5e3985045c6fbf3',1,'UVSOCK_H.txt']]],
  ['xu64',['xU64',['../group__uvsock__typedefs.html#gad43617c3693e772d6d8659876870a777',1,'UVSOCK.h']]],
  ['xuc8',['xUC8',['../group__uvsock__typedefs.html#gad4d975240bd4ac455194fc555029c400',1,'UVSOCK.h']]],
  ['xword16',['xWORD16',['../group__uvsock__typedefs.html#ga89c1c11996cae8e1657362bf38696e60',1,'UVSOCK.h']]]
];
