var structSERIO =
[
    [ "aBytes", "structSERIO.html#a754379bbff07079227cd7e98a94bf7c3", null ],
    [ "aWords", "structSERIO.html#a0d9171c2a337d08f22e06f21c453807a", null ],
    [ "itemMode", "structSERIO.html#aad195fdf30368e06f59316e9a1fefddc", null ],
    [ "nChannel", "structSERIO.html#a2743f7025065258b6fffaa75b2300b19", null ],
    [ "nMany", "structSERIO.html#a2f375029d98970d4c860fd2525fc19b4", null ],
    [ "s", "structSERIO.html#ad56c3976374f41d810aa2cde8074c94d", null ]
];