var group__pgcmd__codes =
[
    [ "PGCMD", "group__pgcmd__codes.html#ga15d1acfbbae141dc41cf3ede7478bba4", [
      [ "UV_PROGRESS_INIT", "group__pgcmd__codes.html#gga15d1acfbbae141dc41cf3ede7478bba4a7f91eacc4495314e1d7e37eaef8ffc27", null ],
      [ "UV_PROGRESS_SETPOS", "group__pgcmd__codes.html#gga15d1acfbbae141dc41cf3ede7478bba4aed87f9dbafe60546187f48d386f94b7f", null ],
      [ "UV_PROGRESS_CLOSE", "group__pgcmd__codes.html#gga15d1acfbbae141dc41cf3ede7478bba4a6f6fef5bce7fd4fedd759fb880f36f65", null ],
      [ "UV_PROGRESS_INITTXT", "group__pgcmd__codes.html#gga15d1acfbbae141dc41cf3ede7478bba4a5b6a00df9919a25cec2d346b3aebde15", null ],
      [ "UV_PROGRESS_SETTEXT", "group__pgcmd__codes.html#gga15d1acfbbae141dc41cf3ede7478bba4a8647339d3f3571b975ba5e9fe33a36bb", null ],
      [ "UV_PROGRESS_END", "UVSOCK_8h.html#ga15d1acfbbae141dc41cf3ede7478bba4a6580d3d05b5e757e5f6d0b4ce980f2a2", null ]
    ] ],
    [ "UV_PROGRESS_CLOSE", "group__pgcmd__codes.html#gga15d1acfbbae141dc41cf3ede7478bba4a6f6fef5bce7fd4fedd759fb880f36f65", null ],
    [ "UV_PROGRESS_INIT", "group__pgcmd__codes.html#gga15d1acfbbae141dc41cf3ede7478bba4a7f91eacc4495314e1d7e37eaef8ffc27", null ],
    [ "UV_PROGRESS_INITTXT", "group__pgcmd__codes.html#gga15d1acfbbae141dc41cf3ede7478bba4a5b6a00df9919a25cec2d346b3aebde15", null ],
    [ "UV_PROGRESS_SETPOS", "group__pgcmd__codes.html#gga15d1acfbbae141dc41cf3ede7478bba4aed87f9dbafe60546187f48d386f94b7f", null ],
    [ "UV_PROGRESS_SETTEXT", "group__pgcmd__codes.html#gga15d1acfbbae141dc41cf3ede7478bba4a8647339d3f3571b975ba5e9fe33a36bb", null ]
];