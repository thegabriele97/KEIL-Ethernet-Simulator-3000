var group__uvsc__cmdo__func =
[
    [ "UVSC_GetCmdOutput", "group__uvsc__cmdo__func.html#ga388075a53f56769493a4d479aff53f82", null ],
    [ "UVSC_GetCmdOutputSize", "group__uvsc__cmdo__func.html#ga66ea289dc379c0872c4ba0209f9a2cf4", null ]
];