var structMENUID =
[
    [ "__pad0__", "structMENUID.html#a656e40e16c7572f1acdd57756db12440", null ],
    [ "menuType", "structMENUID.html#a8435160434bdea4815b278dc41763b80", null ],
    [ "nID", "structMENUID.html#aa4f2c2666470411eb3414dd771a5ea92", null ]
];