var structUVLICINFO =
[
    [ "__pad0__", "structUVLICINFO.html#aa6e5474e05fc950bd4af08fbe6403e07", null ],
    [ "nRes", "structUVLICINFO.html#a0c56c618c4d0e1e94516c6dc85007aa9", null ],
    [ "rvmdk", "structUVLICINFO.html#ad88898b47d65e7ec7314436716adb2cb", null ]
];