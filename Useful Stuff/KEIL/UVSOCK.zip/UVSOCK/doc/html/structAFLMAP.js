var structAFLMAP =
[
    [ "iFile", "structAFLMAP.html#adca247b1d9ee5a74c6675a108414320d", null ],
    [ "iFunc", "structAFLMAP.html#a5ffde0fa6bc375ed9382c1bd182911f6", null ],
    [ "nAdr", "structAFLMAP.html#a73990e899cf2a795d1e2af241799e0e0", null ],
    [ "nLine", "structAFLMAP.html#a644502e9548f4e5f87909b9ae4144a12", null ],
    [ "nRes", "structAFLMAP.html#a568211f9aac99f32e264865552adf491", null ],
    [ "szFile", "structAFLMAP.html#ae2037e025637e66a9f76328135d44950", null ]
];