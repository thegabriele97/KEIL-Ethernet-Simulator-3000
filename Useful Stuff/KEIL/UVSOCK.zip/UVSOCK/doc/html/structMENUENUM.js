var structMENUENUM =
[
    [ "__pad0__", "structMENUENUM.html#a2c85e709ed1a7d92cfd12a35a3e1ad6a", null ],
    [ "bEnabled", "structMENUENUM.html#a706a37cb787d3201953e376617b9d1bd", null ],
    [ "infoType", "structMENUENUM.html#a8327e421a96c7924e1781d39c681bb20", null ],
    [ "menuLabel", "structMENUENUM.html#a161c9b04c218bfa8fe62cab5fa52fb44", null ],
    [ "menuType", "structMENUENUM.html#a42a29858b8f9a1f92a9f0555581c2fdb", null ],
    [ "nID", "structMENUENUM.html#a535033e927c552eeac7c5f233cc728a8", null ]
];