// STimerDLL.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "Agsi.h"
#include "STimerDLL.h"
#include "PeriDialog.h"
#include "Common.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CSTimerDLLApp

BEGIN_MESSAGE_MAP(CSTimerDLLApp, CWinApp)
	//{{AFX_MSG_MAP(CSTimerDLLApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSTimerDLLApp construction

CSTimerDLLApp::CSTimerDLLApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSTimerDLLApp object

CSTimerDLLApp theApp;


//------------------------------------------------------------------------------------------
// Timer 3 is identical to a standard Timer 1 of a 8051 but has different SFR 
// addresses so that it does not conflict with Timer 1
// The original Timer 1 SFR addresses and pins are:
// sfr TCON  = 0x88;
// sfr TMOD  = 0x89;
// sfr TL1   = 0x8B;
// sfr TH1   = 0x8D;
// T1 pin    = P3.5  Timer 1 external counter input
// INT1 pin  = P3.3  Timer 1 gate control

// The Timer 3 SFR addresses and pins are:
// sfr T3CON = 0xD8;   // Timer 3 register definitions
// sfr T3MOD = 0xD9;
// sfr TL3   = 0xDA;
// sfr TH3   = 0xDB;
// T3 pin    = P1.2  Timer 3 external counter input
// INT3 pin  = P1.3  Timer 3 gate control
//------------------------------------------------------------------------------------------

DWORD DefineAllSFR(void) {           // declare all special function registers and their bits
  BOOL ret = TRUE;

  ret &= Agsi.DefineSFR("T3CON",  T3CON,  AGSIBYTE, 0);  // If more SFR's are defined, do it in a table
  ret &= Agsi.DefineSFR("T3MOD",  T3MOD,  AGSIBYTE, 0);
  ret &= Agsi.DefineSFR("TL3",    TL3,    AGSIBYTE, 0);
  ret &= Agsi.DefineSFR("TH3",    TH3,    AGSIBYTE, 0);

  // It is only allowed to define bits which are bitaddressable.
  ret &= Agsi.DefineSFR("TF3",    T3CON,  AGSIBIT,  7);
  ret &= Agsi.DefineSFR("TR3",    T3CON,  AGSIBIT,  6);
  ret &= Agsi.DefineSFR("ET3",    IE,     AGSIBIT,  6);
  ret &= Agsi.DefineSFR("PT3",    IP,     AGSIBIT,  6);

  return(ret);
}

//------------------------------------------------------------------------------------------

struct vtrlist VTREG[] = {           // VTR's definition: keep this table consistent with defines in SPeriDLL.h
  { "PORT1",   AGSIVTRCHAR, 0x00000000, NULL },
};

DWORD DefineAllVTREG(void) {         // declare all virtual registers
  BOOL ret = TRUE;
  int i;

  for (i = 0; i < (sizeof(VTREG) / sizeof (VTREG[0])); i++) {
    VTREG[i].hVTR = Agsi.DefineVTR(VTREG[i].pName, VTREG[i].Type, VTREG[i].Value);
	if (!VTREG[i].hVTR) ret = FALSE;
  }

  return(ret);
}

//------------------------------------------------------------------------------------------

AGSIINTERRUPT Interrupt = {     // Table of all Interrupts of this module
// vec    *mess           msfr mmask *mname  rsfr   rmask *rname  esfr  emask *ename  p0sfr p0mask *pname p1sfr p1mask pwl auto_reset
   0x3B, "Timer 3",        0,  0,     "",    T3CON, 0x80, "TF3",  IE,   0x40, "ET3",  IP,   0x40,  "Pri", 0,     0x00,  7,  1         // TF3
};


DWORD DefineAllInterrupts(void) {   // define all interrupts

  if (!Agsi.DeclareInterrupt(&Interrupt)) return(FALSE);

  return(TRUE);
}

//------------------------------------------------------------------------------------------

AGSITIMER SWTimer;    // uVision 2 Timer

DWORD DefineAllWatches(void) {      // define all Watches
  BOOL ret = TRUE;

  ret &= Agsi.SetWatchOnSFR(TH3,   timer3, AGSIREADWRITE);
  ret &= Agsi.SetWatchOnSFR(TL3,   timer3, AGSIREADWRITE);
  ret &= Agsi.SetWatchOnSFR(T3CON, timer3, AGSIREADWRITE);
  ret &= Agsi.SetWatchOnSFR(T3MOD, timer3, AGSIWRITE);
  ret &= Agsi.SetWatchOnVTR(PORT1, timer3, AGSIWRITE);

  SWTimer = Agsi.CreateTimer(timer3);
  if (!SWTimer) return(FALSE);

  return(ret);
}

//------------------------------------------------------------------------------------------

DWORD DefineAllMenuEntries(void) {  // declare all peripheral-menu entries and dialogs

  if (!Agsi.DefineMenuItem(&PeriMenu)) return(FALSE);

  return(TRUE);
}

//------------------------------------------------------------------------------------------

DWORD ResetPeripheral(void) {       // reset all SFR's of this peripheral
  BOOL ret = TRUE;
  
  ret &= Agsi.WriteSFR(T3CON,  0x00, 0xC0);
  ret &= Agsi.WriteSFR(T3MOD,  0x00, 0xF0);
  ret &= Agsi.WriteSFR(TL3,    0x00, 0xFF);
  ret &= Agsi.WriteSFR(TH3,    0x00, 0xFF);

  return(ret);
}

//------------------------------------------------------------------------------------------
// This function is directly called from uVision to initialize the DLL and to define all SFR's ...

extern "C" DWORD AGSIEXPORT AgsiEntry (DWORD nCode, void *vp) {
  DWORD CpuType;

  switch (nCode) {
    case AGSI_CHECK:
      CpuType = *((DWORD *)vp);
      if (CpuType == 8051) return(1);  // This driver supports the 8051 family of microcontrollers 
      else                 return(0);  // Other microcontrollers are not supported by the driver
      break;

    case AGSI_INIT:                    // Declare all SFR's, VTREG's, Watches and Interrupts here
      AgsiConfig = *((AGSICONFIG *)vp);
//    AgsiConfig.m_hInstance;          // this pointer is used to get the function addresses of uVision
//    AgsiConfig.m_pszProjectPath;     // Path to application e.g. C:\KEIL\C51\EXAMPLES\HELLO
//    AgsiConfig.m_pszDevice;          // Simulated Device e.g. 52. This string is extracted out of the -p option.
//    AgsiConfig.m_pszConfiguration;   // complete dialog DLL options e.g. -p52 -dmydll ...
//    AgsiConfig.m_pszAppFile;         // name of loaded OMF file including path e.g. C:\KEIL\C51\EXAMPLES\HELLO\HELLO

      if (!GetFunctionPointers()) return(FALSE);   // get all function pointers for Agsi calls
      if (!DefineAllSFR()) return(FALSE);          // define all special function registers
      if (!DefineAllVTREG()) return(FALSE);        // define all virtual registers
      if (!DefineAllInterrupts()) return(FALSE);   // define all interrupts
	  if (!DefineAllWatches()) return(FALSE);      // define all watches
      if (!DefineAllMenuEntries()) return(FALSE);  // define all peripheral-menu entries and dialogs
      break;

    case AGSI_TERMINATE:               // Free all allocated memory, close all files ...
      break;

    case AGSI_RESET:                   // Reset all SFR's of this peripheral
      if (!ResetPeripheral()) return(FALSE);
	  break;

    case AGSI_PREPLL:                  // Recalculate all peripherals before clock prescaler/PLL is set to a new value
      break;

    case AGSI_POSTPLL:                 // Recalculate all peripherals after clock prescaler/PLL is set to a new value
      break;
  }
  return(TRUE);       // return OK
}


// --------------------------------------------------------------------------------------------------
// Simulation of Timer 3
static DWORD  t3disable = 0;          /* to prevent from recursivity */
static DWORD  t3con,  t3mod,  th3,  tl3,  ie;   // Current values
static DWORD  t3conp, t3modp, th3p, tl3p, iep;  // Previous values

union HL  {                        /* High / Low Union  */
   DWORD         v;                
   BYTE          c[2];
   WORD          i[2];
};

#define L      c[0]                /* Low Teil of 16-Bit Reg  */
#define H      c[1]                /* High Teil of 16-Bit Reg */
#define O      i[1]                /* Overflow                */

#define t3timediff   (DWORD)(CurrentStates - lastt3states)

void timer3 (void) {
  union HL    t3;
  union HL  help;
  WORD       ovl;
  DWORD      run;
  DWORD  t3hdiff;
  DWORD    thelp;
  DWORD    port1;
  static DWORD oldport1;
  DWORD  SWTimerValue;
  static INT64 lastt3states, CurrentStates;
  static DWORD  lastt3cpin;

  if (t3disable) return;  // this is to avoid recursivity
  t3disable = 1;
//  read all SFR's and ports that are necessary to simulate the timer 3
  Agsi.ReadSFR(T3CON,  &t3con,  &t3conp,  0xC0);
  Agsi.ReadSFR(T3MOD,  &t3mod,  &t3modp,  0xF3);
  Agsi.ReadSFR(TH3,    &th3,    &th3p,    0xFF);
  Agsi.ReadSFR(TL3,    &tl3,    &tl3p,    0xFF);
  Agsi.ReadSFR(IE,     &ie,     &iep,     0x40);
  port1 = 0;
  Agsi.ReadVTR(PORT1, &port1);

  SWTimerValue = 0xffffffff;   /* clear time watch */
  CurrentStates = Agsi.GetStates();

  t3.v = 0;
  t3.L = (BYTE)tl3p;
  t3.H = (BYTE)th3p;
  ovl = 0;

  run = t3conp & 0x40;
  if ((t3modp & 0x03) == 0x03) run = 1;
  if ((t3modp & 0x30) == 0x30) run = 0;

  /* Calculate actual timer content from last values and difftime */
  if (run && (!(t3modp & 0x80) || (oldport1 & 0x08)))  {
    if ((t3modp & 0x40))  {
      if ((lastt3cpin) && !(port1 & 0x04))  switch (t3modp & 0x30)  {
        /* counter mode */
        case 0x00:
          t3.L <<= 3;
          t3.v += 8;
          t3.L >>= 3;
          ovl = t3.O;
          break;

        case 0x10:
          t3.v++;
          ovl = t3.O;
          break;

        case 0x20:
          help.v = 0;
          help.L = t3.L;
          help.v++;
          if (help.v > 0xff)  {
            ovl = 1;
            t3.L = help.L + t3.H;
          }
          else  {
            t3.L = help.L;
          }
          break;   
         
        case 0x30:
          break;

      }
    }
    else  {                          /* timer mode */
      switch (t3modp & 0x30)  {      /* last timer mode */
        case 0x00:
          t3.L <<= 3;
          t3.v += ((t3timediff) << 3);
          t3.L >>= 3;
          ovl = t3.O;
          break;

        case 0x10:
          t3.v += t3timediff;
          ovl = t3.O;
          break;

        case 0x20:
          t3hdiff = t3timediff + t3.L;
          if (t3hdiff >= 0x100)  {
            ovl   = 1;
            thelp = 0x100 - t3.H;
            t3hdiff -= 0x100;
            t3.L  = (BYTE)((t3hdiff % thelp) + t3.H);
          } else {
            t3.L = (BYTE)t3hdiff;
          }
          break;   
         
        case 0x30:
          break;

      }
    }
    if ((t3mod & 0x03) != 0x03)  {
	  if (ovl  && (! (Agsi.GetLastMemoryAddress() == ((amDATA << 24) | T3CON)))) {
		t3con |= 0x80;
	  }
    }
  }

  lastt3states = CurrentStates;
  lastt3cpin = port1 & 0x04;

// In case of a write access to TH3 or TL3 these values must be taken instead,
// of the calculated ones 
  if (Agsi.GetLastMemoryAddress() == ((amDATA << 24) | TH3)) t3.H = (BYTE)th3;
  if (Agsi.GetLastMemoryAddress() == ((amDATA << 24) | TL3)) t3.L = (BYTE)tl3;

  tl3 = t3.L;
  th3 = t3.H;

  run = t3con & 0x40;
  if ((t3mod & 0x03) == 0x03) run = 1;
  if ((t3mod & 0x30) == 0x30) run = 0;

  /* Calculate timer 3 overflow time form actual content and curr values */
  if (run && (!(t3mod & 0x80) || (port1 & 0x08)))  {
    if (t3mod & 0x40)  {             /* counter mode */
//  no calculations in counter mode necessary
    } else  {                        /* timer mode */
      switch (t3mod & 0x30)  {       /* new timer mode */
        case 0x00:
          t3.L *= 8;
          t3.i[0] /= 8;
          SWTimerValue = 0x2000L - t3.i[0];
          break;

        case 0x10:
          SWTimerValue = 0x10000L - t3.i[0];
          break;

        case 0x20:
          SWTimerValue = 0x100L - t3.L;
          break;


        case 0x30:
          SWTimerValue = 0x100L - t3.L;
          break;
      }
      if ((ie & 0x40) == 0  || (t3mod & 0x03) == 0x03)  {
        SWTimerValue += 0x1000000L;
      }
    }
  }
// Write all SFR values back which might have been modified
  Agsi.WriteSFR(TH3,   th3,   0xFF); 
  Agsi.WriteSFR(TL3,   tl3,   0xFF);
  Agsi.WriteSFR(T3CON, t3con, 0x80);

  oldport1 = port1;
// Set the software timer to the timer 3 overflow.
  Agsi.SetTimer(SWTimer, SWTimerValue);
  t3disable = 0;
}

/*************** End of Timer 3 **************/
