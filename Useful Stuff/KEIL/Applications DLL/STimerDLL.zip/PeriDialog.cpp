// PeriDialog.cpp : implementation file
// Peripheral Dialog: Timer 3 for 8051 Derivatives.

#include "stdafx.h"
#include "Agsi.h"
#include "STimerDLL.h"
#include "PeriDialog.h"
#include "Common.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Protoyptes for forward references
static void PeriUpdate (void);
static void PeriKill   (AGSIDLGD *pM);
static void PeriDisp   (AGSIMENU *pM);

/////////////////////////////////////////////////////////////////////////////
// CPeriDialog dialog

static CPeriDialog  * pCPeriDialog;
BYTE initflag = 0;

// must not use 'const' here !
//                     iOpen  Hwnd   Dlg Proc.  Rect: -1 := default    Update       Kill
AGSIDLGD PeriDlg =  {    0,   NULL,      NULL,  { -1, -1, -1, -1, },  PeriUpdate,  PeriKill };

// The following line specifies the menu entry in the peripheral pull down menu. 
// The '&' and the following character in the sting specifies the keyboard shortcut. <Alt+3> in this case.  
//                    nDelim   *szText            *fp      nID   nDlgId         *pDlg;
AGSIMENU PeriMenu =  {  1,   "Timer &3"        , PeriDisp,  0,   IDD_TC3,      &PeriDlg   };  // Peripheral Dialog


static DWORD  t3con,  t3mod,  th3,  tl3;   // Current values
static DWORD  t3conp, t3modp, th3p, tl3p;  // Previous values



static void PeriUpdate (void)  {            // Update Function
  if (pCPeriDialog) pCPeriDialog->Update();
}

static void PeriKill (AGSIDLGD *pM)  {      // Kill Function
  if (pCPeriDialog == NULL) return;
  pCPeriDialog->SendMessage (WM_CLOSE);
  pCPeriDialog  = NULL;
  pM->iOpen = 0;
  pM->hw    = NULL;
}

static void PeriDisp (AGSIMENU *pM)  {
  if (pM->pDlg->hw != NULL)  {              // created
    PeriKill (pM->pDlg);                    // close
  } else  {
//    AFX_MANAGE_STATE(AfxGetStaticModuleState());// -- not necessary.
    pCPeriDialog = new CPeriDialog (pM, NULL);     // modeless construction
    if (pCPeriDialog != NULL)  {                   // construction was Ok.
      pM->pDlg->hw = pCPeriDialog->m_hWnd;         // Dialog handle
    }
  }
}

CPeriDialog::CPeriDialog (AGSIMENU *pMen, CWnd *pWnd)  {
  pM = pMen;                     // save DYM-Descriptor locally.
  Create (IDD_TC3, pWnd);
  pCPeriDialog = this;
}


// standard constructor does not work here because we are using modeless dialogs
//CPeriDialog::CPeriDialog(CWnd* pParent /*=NULL*/)
//	: CDialog(CPeriDialog::IDD, pParent)
//{
	//{{AFX_DATA_INIT(CPeriDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
//}


void CPeriDialog::Update (void)  {          /* Update Dialog Contents */
  DWORD  port1;
  static DWORD  port1d;
  static DWORD  t3cond, t3modd, th3d, tl3d;  // Displayed values
  char  *pText;
  static DWORD statdisp;
  DWORD  i;

  timer3();             // Update all Timer 3 values
  Agsi.ReadSFR(T3CON,  &t3con,  &t3conp,  0xFF);
  Agsi.ReadSFR(T3MOD,  &t3mod,  &t3modp,  0xFF);
  Agsi.ReadSFR(TH3,    &th3,    &th3p,    0xFF);
  Agsi.ReadSFR(TL3,    &tl3,    &tl3p,    0xFF);
  port1 = 0;
  Agsi.ReadVTR(PORT1, &port1);

  if (initflag) {
    tl3d    = ~tl3;
    th3d    = ~th3;
    t3modd  = ~t3mod;
    t3cond  = ~t3con;
    port1d  = ~port1;
    statdisp = -1;
    initflag = 0;
  }

  if (t3modd != t3mod) {
    StringHex2 (GetDlgItem (IDC_T3TMOD), t3mod);
    if ((t3modd ^ t3mod) & 0x30) ((CComboBox *) GetDlgItem (IDC_T3MODE))->SetCurSel((t3mod & 0x30) >> 4);
    if ((t3modd ^ t3mod) & 0x40) ((CComboBox *) GetDlgItem (IDC_T3INMODE))->SetCurSel((t3mod & 0x40) >> 6);
    if ((t3modd ^ t3mod) & 0x80) ((CButton *)   GetDlgItem (IDC_T3GATE))->SetCheck ((t3mod & 0x80) ? 1 : 0);
  }
  if (t3cond != t3con) {
    StringHex2 (GetDlgItem (IDC_T3TCON), t3con);
    if ((t3cond ^ t3con) & 0x40) ((CButton *) GetDlgItem (IDC_TR3))->SetCheck ((t3con  & 0x40) ? 1 : 0);
    if ((t3cond ^ t3con) & 0x80) ((CButton *) GetDlgItem (IDC_TF3))->SetCheck ((t3con  & 0x80) ? 1 : 0);
  }
  if (th3d   != th3)    StringHex2 (GetDlgItem (IDC_TH3),    th3);
  if (tl3d   != tl3)    StringHex2 (GetDlgItem (IDC_TL3),    tl3);
  if ((port1d ^ port1) & 0x04)    ((CButton *) GetDlgItem (IDC_T3PIN))->SetCheck ((port1 & 0x04) ? 1 : 0);
  if ((port1d ^ port1) & 0x08)    ((CButton *) GetDlgItem (IDC_T3INT3))->SetCheck ((port1 & 0x08) ? 1 : 0);

  i = t3con & 0x40;
  if ((t3mod & 0x03) == 0x03) i = 1;
  if ((t3mod & 0x30) == 0x30) i = 0;
  i = i && (!(t3mod & 0x80) || (port1 & 0x08));
  if (i != statdisp) {
    pText = i ? "Run" : "Stop";
    SetDlgItemText (IDC_T3STAT, pText);      /* Status */
    statdisp = i;
  }

  tl3d     = tl3;
  th3d     = th3;
  t3modd   = t3mod;
  t3cond   = t3con;
  port1d   = port1;
  statdisp = 0xFFFF;
}


BEGIN_MESSAGE_MAP(CPeriDialog, CDialog)
	//{{AFX_MSG_MAP(CPeriDialog)
	ON_WM_CLOSE()
	ON_WM_ACTIVATE()
	ON_CBN_SELCHANGE(IDC_T3MODE, OnSelchangeT3mode)
	ON_CBN_SELCHANGE(IDC_T3INMODE, OnSelchangeT3inmode)
	ON_EN_KILLFOCUS(IDC_T3TCON, OnKillfocusT3tcon)
	ON_EN_KILLFOCUS(IDC_T3TMOD, OnKillfocusT3tmod)
	ON_EN_KILLFOCUS(IDC_TH3, OnKillfocusTh3)
	ON_EN_KILLFOCUS(IDC_TL3, OnKillfocusTl3)
	ON_BN_CLICKED(IDC_T3PIN, OnT3pin)
	ON_BN_CLICKED(IDC_TF3, OnTf3)
	ON_BN_CLICKED(IDC_TR3, OnTr3)
	ON_BN_CLICKED(IDC_T3GATE, OnT3gate)
	ON_BN_CLICKED(IDC_T3INT3, OnT3int3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPeriDialog message handlers

void CPeriDialog::PostNcDestroy() {
	
  delete this;              // delete the new'ed object
  pCPeriDialog = NULL;      // clear external Object pointer here.
}

void CPeriDialog::OnClose() {
	
  GetWindowRect (&pM->pDlg->rc);  // save Window position
  pM->pDlg->hw = NULL;            // clear m_hWnd
  DestroyWindow();                //--- modeless
}

static const char *tim3in[2] = {      /* for Mode-Combo-Box */
  "Timer",
  "Counter"
};
static const char *tim3m[4] = {       /* for Input-Combo-Box (counter mode) */
  "0: 13 Bit Timer/Counter",
  "1: 16 Bit Timer/Counter",
  "2: 8 Bit auto-reload",
  "3: Disabled"
};


BOOL CPeriDialog::OnInitDialog() {
  CDialog::OnInitDialog();
  DWORD i;
	
  // TODO: Add extra initialization here

  // Restore Position (Only moving without resizing)
  if (PeriDlg.rc.left != -1) {
 	SetWindowPos(NULL,                        /* placement order - not used */
                 PeriDlg.rc.left,             /* left */
                 PeriDlg.rc.top,              /* top  */
                 0,                           /* width - not used */
                 0,                           /* height - not used */
                 SWP_NOSIZE | SWP_NOZORDER);  /* flags */
  }

  for ( i = 0 ; i < 4 ; ++i )  {           /* Fill ComboBox   */
    ((CComboBox *) GetDlgItem (IDC_T3MODE))->AddString((LPCSTR) tim3m[i]);
  }
  for ( i = 0 ; i < 2 ; ++i )  {           /* Fill ComboBox   */
    ((CComboBox *) GetDlgItem (IDC_T3INMODE))->AddString((LPCSTR) tim3in[i]);
  }
	
  initflag =1;
  Update();
  return TRUE;  // return TRUE unless you set the focus to a control
                // EXCEPTION: OCX Property Pages should return FALSE
}

void CPeriDialog::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) {
  CDialog::OnActivate(nState, pWndOther, bMinimized);
	
  switch (nState)  {
    case WA_INACTIVE:
      Agsi.HandleFocus(NULL);      // Clear Modeless Handle
      break;
    case WA_ACTIVE:
    case WA_CLICKACTIVE:
      Agsi.HandleFocus(m_hWnd);    // Set Modeless Handle
      break;
  }
}


void CPeriDialog::OnSelchangeT3mode() {
  int i;
  DWORD val;
	
  i = ((CComboBox *) GetDlgItem (IDC_T3MODE))->GetCurSel(); 
  val = (i & 3) << 4;
  Agsi.WriteSFR(T3MOD, val, 0x30);
  Agsi.UpdateWindows();
}

void CPeriDialog::OnSelchangeT3inmode() {
  int i;
  DWORD val;
	
  i = ((CComboBox *) GetDlgItem (IDC_T3INMODE))->GetCurSel(); 
  val = (i & 1) << 6;
  Agsi.WriteSFR(T3MOD, val, 0x40);
  Agsi.UpdateWindows();
}

void CPeriDialog::OnKillfocusT3tcon() { HandleByteInput (GetDlgItem(IDC_T3TCON), T3CON); } 
void CPeriDialog::OnKillfocusT3tmod() { HandleByteInput (GetDlgItem(IDC_T3TMOD), T3MOD); }
void CPeriDialog::OnKillfocusTh3()    { HandleByteInput (GetDlgItem(IDC_TH3),    TH3);   }
void CPeriDialog::OnKillfocusTl3()    { HandleByteInput (GetDlgItem(IDC_TL3),    TL3);   }

void CPeriDialog::OnT3pin()  { WriteBitVTR(PORT1, 0x04, IsDlgButtonChecked (IDC_T3PIN));  }
void CPeriDialog::OnT3int3() { WriteBitVTR(PORT1, 0x08, IsDlgButtonChecked (IDC_T3INT3)); }

void CPeriDialog::OnTf3() {    WriteBit(T3CON, 0x80, IsDlgButtonChecked (IDC_TF3));    }
void CPeriDialog::OnTr3() {    WriteBit(T3CON, 0x40, IsDlgButtonChecked (IDC_TR3));    }
void CPeriDialog::OnT3gate() { WriteBit(T3MOD, 0x80, IsDlgButtonChecked (IDC_T3GATE)); }


// The following two functions and the corresponding invisible buttons are necessary 
// to handle the behavior of the ESC and Enter Keys 
void CPeriDialog::OnOK() {
	
//	CDialog::OnOK();  // Do nothing when <Enter> is pressed
}

void CPeriDialog::OnCancel() {
	
  OnClose();            // Close Dialog when <ESC> is pressed 
}

