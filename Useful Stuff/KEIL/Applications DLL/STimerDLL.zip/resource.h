//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by STimerDLL.rc
//
#define IDD_TC3                         200
#define IDC_T3TCON                      1035
#define IDC_T3TMOD                      1036
#define IDC_TH3                         1037
#define IDC_TL3                         1038
#define IDC_T3PIN                       1039
#define IDC_TF3                         1040
#define IDC_TR3                         1041
#define IDC_T3GATE                      1042
#define IDC_T3INT3                      1043
#define IDC_T3MODE                      1840
#define IDC_T3INMODE                    1841
#define IDC_T3STAT                      1842

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1000
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
